<?php

// RabbitMQ connection
require_once __DIR__ . '/vendor/autoload.php';
use PhpAmqpLib\Connection\AMQPStreamConnection;
use PhpAmqpLib\Message\AMQPMessage;

// RabbitMQ connection settings
$host = '18.207.17.153';
$port = 5672;
$user = 'MQServer';
$pass = 'IT490';
$vhost = '/';
$exchange = 'recipes_details';
$likes_queue = 'recipe_likes'; // New queue for sending likes
$response_queue = 'response_queue'; // Response queue for receiving replies

// Check if the form is submitted for like processing
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['recipeId'])) {
    try {
        // Create connection
        $connection = new AMQPStreamConnection($host, $port, $user, $pass, $vhost);
        $channel = $connection->channel();

        $correlationId = uniqid();

        // Declare response queue
        list($callback_queue, ,) = $channel->queue_declare("", false, false, true, false);
        
        $callback = function ($msg) use ($correlationId) {
            if ($msg->get('correlation_id') == $correlationId) {
                echo "Response received: " . $msg->body;
            }
        };

        // Retrieve user email from session
        session_start();
        
        $userEmail = $_SESSION['email']; // Adjust this to your actual session handling

        // Prepare like data
        $likeData = [
            'userEmail' => $userEmail,
            'idmeal' => $_POST['recipeId']
        ];

        // Convert like data to JSON
        $likeJson = json_encode($likeData);

        // Send like to RabbitMQ
        $msg = new AMQPMessage($likeJson, [
            'correlation_id' => $correlationId,
            'reply_to' => $callback_queue
        ]);
        $channel->basic_publish($msg, '', $likes_queue);

        // Wait for the response
        $channel->basic_consume($callback_queue, '', false, true, false, false, $callback);

        while (!$response) {
            $channel->wait();
        }

        echo "Like sent successfully for recipe ID: {$_POST['recipeId']}";

        // Close connection
        $channel->close();
        $connection->close();
    } catch (\PhpAmqpLib\Exception\AMQPTimeoutException $e) {
        echo "Error: Timeout connecting to RabbitMQ";
        error_log("RabbitMQ Timeout Exception: " . $e->getMessage());
    } catch (\Exception $e) {
        echo "Error: Failed to send like for recipe ID: {$_POST['recipeId']}";
        error_log("Exception occurred: " . $e->getMessage());
    }
} else {
    echo "Error: Invalid request";
}

?>
