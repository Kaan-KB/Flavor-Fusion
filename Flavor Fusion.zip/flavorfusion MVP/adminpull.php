<?php
session_start();

require_once __DIR__ . '/vendor/autoload.php';
use PhpAmqpLib\Connection\AMQPStreamConnection;
use PhpAmqpLib\Message\AMQPMessage;

// Include session timeout management
include 'sessiontimeout.php';
include 'nav.php'; 

?> 

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Admin Pull Data</title>
    <link rel="stylesheet" href="styles/styles.css"> 
</head>
<body>
    <h2>Admin Pull Data</h2>

    <button id="pullDataBtn">Pull New Data</button>

    <div id="pullStatus"></div>

    <script>
        document.getElementById('pullDataBtn').addEventListener('click', function() {
            fetch('fetch_data.php', {
                method: 'POST',
                body: JSON.stringify({ action: 'fetch_data' }),
                headers: {
                    'Content-Type': 'application/json'
                }
            })
            .then(response => {
                if (!response.ok) {
                    throw new Error('Network response was not ok');
                }
                return response.json();
            })
            .then(data => {
                let pullStatusDiv = document.getElementById('pullStatus');
                pullStatusDiv.innerHTML = `<p>Data pulled successfully!</p>`;
            })
            .catch(error => {
                console.error('Error pulling data:', error);
                let pullStatusDiv = document.getElementById('pullStatus');
                pullStatusDiv.innerHTML = `<p>Error pulling data. Please try again later.</p>`;
            });
        });
    </script>
</body>
</html>
