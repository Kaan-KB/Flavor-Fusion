<!DOCTYPE html>
<html>
<?php include 'nav.php'; ?>
<link rel="stylesheet" href="styles/styles.css">
<head>
    <title>Logout</title>
</head>
<body>
    <h1>You have been logged out successfully. See you again soon!</h1>
</body>
</html>
