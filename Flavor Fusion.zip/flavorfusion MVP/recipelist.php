<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Recipe List</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .card {
            margin: 10px;
        }
        .card-img-top {
            height: 200px;
            object-fit: cover;
        }
    </style>
</head>
<body>
<?php
// Start or resume session
include 'sessiontimeout.php';

session_start();

// Check if user is logged in
if (isset($_SESSION['email'])) {
    include 'nav.php'; // Include navigation bar for logged-in users
} else {
    // Redirect to login page if user is not logged in
    $_SESSION['error'] = "You must be logged in to view this page.";
    header("Location: login.php");
    exit();
}
?>

<div class="container">
    <h2 class="my-4">Recipe List</h2>
    
    <!-- Search Input -->
    <div class="row mb-4">
        <div class="col-md-6">
            <label for="searchInput">Search:</label>
            <input type="text" class="form-control" id="searchInput" placeholder="Enter search term">
        </div>
        <div class="col-md-6">
            <button id="searchBtn" class="btn btn-primary mt-4">Search</button>
        </div>
    </div>
    
    <!-- Recipe Cards -->
    <div class="row" id="recipeList">
        <!-- Recipe cards will be displayed here -->
    </div>
</div>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        fetchRecipeData(); // Fetch initial data when page loads

        // Event listener for search button
        document.getElementById('searchBtn').addEventListener('click', function() {
            fetchRecipeData(); // Fetch data on search button click
        });

        // Event listener for search input on Enter key press
        document.getElementById('searchInput').addEventListener('keydown', function(event) {
            if (event.key === 'Enter') {
                fetchRecipeData(); // Fetch data on Enter key press in search input
            }
        });

        // Event delegation for dynamically loaded content
        document.getElementById('recipeList').addEventListener('click', function(event) {
            const recipeCard = event.target.closest('.recipe-card');
            if (recipeCard) {
                const recipeId = recipeCard.dataset.recipeId;
                window.location.href = `recipedetails.php?id=${recipeId}`; // Adjust URL as per your backend setup
            }
        });
    });

    // Function to fetch recipe data based on search term
    function fetchRecipeData() {
        const searchInput = document.getElementById('searchInput').value.trim();

        fetch('fetch_data.php', {
            method: 'POST',
            body: JSON.stringify({ action: 'fetch_data', search: searchInput }),
            headers: {
                'Content-Type': 'application/json'
            }
        })
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return response.json();
        })
        .then(data => {
            let recipeListDiv = document.getElementById('recipeList');
            recipeListDiv.innerHTML = ''; // Clear previous data

            if (data.error) {
                recipeListDiv.innerHTML = `<div class="col-12"><p class="alert alert-danger">Error fetching data: ${data.error}</p></div>`;
            } else {
                data.forEach(recipe => {
                    let card = `
                        <div class="col-md-4">
                            <div class="card recipe-card" data-recipe-id="${recipe.idMeal}">
                                <a href="#" class="card-link">
                                    <img src="${recipe.strMealThumb}" class="card-img-top" alt="${recipe.strMeal}">
                                    <div class="card-body">
                                        <h5 class="card-title">${recipe.strMeal}</h5>
                                        <p class="card-text">${recipe.strCategory}</p>
                                        <p class="card-text">${recipe.strArea}</p>
                                    </div>
                                </a>
                            </div>
                        </div>
                    `;
                    recipeListDiv.innerHTML += card;
                });
            }
        })
        .catch(error => {
            console.error('Error fetching data:', error);
            let recipeListDiv = document.getElementById('recipeList');
            recipeListDiv.innerHTML = `<div class="col-12"><p class="alert alert-danger">Error fetching data. Please try again later.</p></div>`;
        });
    }
</script>

</body>
</html>
