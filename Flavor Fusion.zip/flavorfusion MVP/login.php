<?php

require_once __DIR__ . '/vendor/autoload.php';
use PhpAmqpLib\Connection\AMQPStreamConnection;
use PhpAmqpLib\Message\AMQPMessage;

$errors = [];

// Include session timeout management
include 'sessiontimeout.php';

if (isset($_SESSION['error'])) {
    $errors[] = $_SESSION['error'];
    unset($_SESSION['error']);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'];
    $password = $_POST['password'];

    // Validate email
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = "Invalid email format";
    }

    // Validate password
    if (strlen($password) < 8) {
        $errors[] = "Password must be at least 8 characters long";
    }

    if (empty($errors)) {
        // Send data to RabbitMQ
        $data = ['action' => 'login', 'email' => $email, 'password' => $password];
        $response = sendToRabbitMQ($data);

        if ($response !== null && isset($response['status']) && $response['status'] == 'success') {
            $_SESSION['email'] = $email;
            $_SESSION['role'] = $response['role']; // Store role in session
            header("Location: home.php");
            exit();
        } else {
            if ($response !== null && isset($response['error'])) {
                $errors[] = "Login failed: " . $response['error'];
            } else {
                $errors[] = "Login failed! Email or Password doesn't exist";
            }
        }
    }
}

function sendToRabbitMQ($data) {
    try {
        $connection = new AMQPStreamConnection('18.207.17.153', 5672, 'MQServer', 'IT490');
        $channel = $connection->channel();

        $channel->queue_declare('login_queue', false, false, false, false);

        // Create a new response queue
        list($responseQueue,,) = $channel->queue_declare("", false, false, true, false);

        // Generate a unique correlation ID
        $correlationId = uniqid();

        // Prepare the message with correlation ID and reply-to queue
        $msg = new AMQPMessage(json_encode($data), [
            'correlation_id' => $correlationId,
            'reply_to' => $responseQueue,
            'content_type' => 'application/json',
            'delivery_mode' => AMQPMessage::DELIVERY_MODE_PERSISTENT
        ]);

        // Publish the message to the login queue
        $channel->basic_publish($msg, '', 'login_queue');

        // Consume the response from the created queue
        $response = null;
        $callback = function ($msg) use (&$response, $correlationId) {
            if ($msg->get('correlation_id') === $correlationId) {
                $response = json_decode($msg->body, true);
            }
        };

        $channel->basic_consume($responseQueue, '', false, true, false, false, $callback);

        // Wait for response
        $timeout = 10; // Timeout in seconds
        $start_time = time();
        while ($response === null && (time() - $start_time) < $timeout) {
            $channel->wait(null, false, $timeout);
        }

        // Close the channel and the connection
        $channel->close();
        $connection->close();

        return $response;

    } catch (Exception $e) {
        echo "Error: " . $e->getMessage();
        return null;
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Login</title>
    <link rel="stylesheet" href="styles/styles.css">
    <?php include 'nav.php'; ?>
</head>
<body>
    <h2>Login</h2>

    <?php
    if (!empty($errors)) {
        echo '<div style="color: red;">';
        foreach ($errors as $error) {
            echo '<p>' . htmlspecialchars($error) . '</p>';
        }
        echo '</div>';
    }
    ?>

    <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
        Email: <input type="email" name="email" required value="<?php echo isset($email) ? htmlspecialchars($email) : ''; ?>"><br>
        Password: <input type="password" name="password" required><br>
        <input type="submit" value="Login">
    </form>
</body>
</html>
