<?php
// Include session timeout management
include 'sessiontimeout.php';
include 'nav.php'; 

require_once __DIR__ . '/vendor/autoload.php';
use PhpAmqpLib\Connection\AMQPStreamConnection;
use PhpAmqpLib\Message\AMQPMessage;

// RabbitMQ connection settings
$host = '18.207.17.153';
$port = 5672;
$user = 'MQServer';
$pass = 'IT490';
$vhost = '/';
$exchange = 'recipes_details';
$likes_queue = 'recipe_likes'; // New queue for sending likes
$response_queue = 'response_queue'; // Response queue for receiving replies
$delete_queue = 'recipe_delete'; // Queue for deleting recipes

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['recipeId'])) {
    try {
        // Reconnect to RabbitMQ
        $connection = new AMQPStreamConnection($host, $port, $user, $pass, $vhost);
        $channel = $connection->channel();

        $recipeId = $_POST['recipeId'];
        $correlationId = uniqid();

        // Retrieve user email from session
        $userEmail = isset($_SESSION['email']) ? $_SESSION['email'] : null;

        if (!$userEmail) {
            echo json_encode(['status' => 'error', 'message' => 'User email not found in session.']);
            exit;
        }

        $likeData = [
            'idMeal' => $recipeId,
            'userEmail' => $userEmail
        ];

        $likeJson = json_encode($likeData);

        $msg = new AMQPMessage($likeJson, [
            'correlation_id' => $correlationId
        ]);
        $channel->basic_publish($msg, '', $likes_queue);

        // Close RabbitMQ connection
        $channel->close();
        $connection->close();

        echo json_encode(['status' => 'success', 'message' => 'Like sent successfully.']);
    } catch (\PhpAmqpLib\Exception\AMQPConnectionException $e) {
        echo json_encode(['status' => 'error', 'message' => 'Failed to connect to RabbitMQ: ' . $e->getMessage()]);
    } catch (\Exception $e) {
        echo json_encode(['status' => 'error', 'message' => 'Exception occurred: ' . $e->getMessage()]);
    }
    exit;
}

try {
    // RabbitMQ connection
    $connection = new AMQPStreamConnection($host, $port, $user, $pass, $vhost);
    $channel = $connection->channel();

    // Check if recipe ID is provided in the URL
    if (!isset($_GET['id'])) {
        echo "<p>Error: Recipe ID not provided.</p>";
        exit;
    }

    $recipeId = $_GET['id'];

    // Fetch recipe details via RabbitMQ
    $correlationId = uniqid();

    // Declare response queue
    list($callback_queue, ,) = $channel->queue_declare("", false, false, true, false);

    $requestData = [
        'idMeal' => $recipeId
    ];

    // Convert request data to JSON
    $requestJson = json_encode($requestData);

    // Send request to RabbitMQ
    $msg = new AMQPMessage($requestJson, [
        'correlation_id' => $correlationId,
        'reply_to' => $callback_queue
    ]);
    $channel->basic_publish($msg, $exchange);

    // Callback function to handle response
    $response = null;
    $callback = function ($msg) use (&$response, $correlationId) {
        if ($msg->get('correlation_id') == $correlationId) {
            $response = $msg->body;
        }
    };

    // Consume response from RabbitMQ
    $channel->basic_consume($callback_queue, '', false, true, false, false, $callback);

    // Wait for the response
    while (!$response) {
        $channel->wait();
    }

    // Decode response
    $recipe = json_decode($response, true);

    // Close RabbitMQ connection
    $channel->close();
    $connection->close();

    // HTML content for recipe details
    ?>
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Recipe Details</title>
        <link rel="stylesheet" href="stylesrd.css">
        <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
        <script>
        function toggleFavorite(button) {
            if (button.textContent === "Favorite") {
                button.textContent = "Unfavorite";
            } else {
                button.textContent = "Favorite";
            }
        }

        function sendLike(recipeId) {
            var formData = new FormData();
            formData.append('recipeId', recipeId);

            $.ajax({
                type: 'POST',
                url: 'recipedetail.php',
                data: formData,
                processData: false,
                contentType: false,
                success: function(response) {
                    console.log(response);
                    // Show pop-up notification
                    var notification = document.createElement('div');
                    notification.textContent = 'Like sent successfully!';
                    notification.style.cssText = 'position: fixed; top: 10px; right: 10px; background-color: #4CAF50; color: white; padding: 15px; z-index: 1000;';
                    document.body.appendChild(notification);

                    setTimeout(function() {
                        notification.style.display = 'none';
                    }, 3000); // Hide notification after 3 seconds
                },
                error: function(xhr, status, error) {
                    console.error('Error sending like:', error);
                }
            });
        }

        function deleteRecipe(recipeId) {
            if (confirm('Are you sure you want to delete this recipe?')) {
                var formData = new FormData();
                formData.append('recipeId', recipeId);

                $.ajax({
                    type: 'POST',
                    url: 'recipedetail.php',
                    data: formData,
                    processData: false,
                    contentType: false,
                    success: function(response) {
                        console.log(response);
                        alert('Recipe deleted successfully!');
                        window.location.href = 'index.php'; // Redirect to homepage after deletion
                    },
                    error: function(xhr, status, error) {
                        console.error('Error deleting recipe:', error);
                    }
                });
            }
        }
        </script>
    </head>
    <body>
    <div class="container">
    <?php
    // Output recipe details
    if (isset($recipe['error'])) {
        echo "<p>Error: {$recipe['error']}</p>";
    } else {
        echo "<h1>{$recipe['strMeal']}</h1>";
        echo "<p>Origin: {$recipe['strArea']}</p>";
        echo "<img src='{$recipe['strMealThumb']}' alt='{$recipe['strMeal']}'>";
        echo "<h2>Ingredients</h2>";
        echo "<ul>";
        for ($i = 1; $i <= 20; $i++) {
            $ingredient = $recipe["strIngredient{$i}"];
            $measure = $recipe["strMeasure{$i}"];
            if (!empty($ingredient)) {
                echo "<li>{$ingredient} - {$measure}</li>";
            }
        }
        echo "</ul>";
        echo "<h2>Instructions</h2>";
        echo "<p>{$recipe['strInstructions']}</p>";
        if (!empty($recipe['strYoutube'])) {
            echo "<h2>Video</h2>";
            echo "<a href='{$recipe['strYoutube']}'>Watch Video</a>";
        }
        echo '<button onclick="sendLike(' . $recipeId . ')">Like</button> <button id="favoriteButton" onclick="toggleFavorite(this)">Favorite</button> <button onclick="deleteRecipe(' . $recipeId . ')">Delete</button>';
    }
    ?>
    </div>
    </body>
    </html>
    <?php

} catch (\PhpAmqpLib\Exception\AMQPConnectionException $e) {
    // Handle RabbitMQ connection errors
    echo "Failed to connect to RabbitMQ: " . $e->getMessage();
} catch (\Exception $e) {
    // Handle other exceptions
    echo "Exception occurred: " . $e->getMessage();
}
?>