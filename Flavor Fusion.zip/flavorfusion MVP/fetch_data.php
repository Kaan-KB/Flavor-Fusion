<?php
require_once __DIR__ . '/vendor/autoload.php';
use PhpAmqpLib\Connection\AMQPStreamConnection;
use PhpAmqpLib\Message\AMQPMessage;

// Enable error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);

$host = '18.207.17.153';
$port = 5672;
$user = 'MQServer';
$pass = 'IT490';
$queue = 'meal_data_queue';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $input = json_decode(file_get_contents('php://input'), true);

    if ($input['action'] === 'fetch_data') {
        try {
            $connection = new AMQPStreamConnection($host, $port, $user, $pass);
            $channel = $connection->channel();

            $channel->queue_declare($queue, false, false, false, false);

            $correlationId = uniqid();

            $responseQueue = 'response_queue';
            $channel->queue_declare($responseQueue, false, false, false, false);

            $callback = function ($msg) use (&$response, $correlationId) {
                if ($msg->get('correlation_id') === $correlationId) {
                    $response = json_decode($msg->body, true);
                }
            };

            $channel->basic_consume($responseQueue, '', false, true, false, false, $callback);

            $msg = new AMQPMessage(
                json_encode(['action' => 'fetch_data']),
                ['correlation_id' => $correlationId, 'reply_to' => $responseQueue]
            );

            $channel->basic_publish($msg, '', $queue);

            while (!$response) {
                $channel->wait();
            }

            echo json_encode($response);

            $channel->close();
            $connection->close();
        } catch (Exception $e) {
            error_log("Error in fetch_data.php: " . $e->getMessage());
            http_response_code(500);
            echo json_encode(['error' => 'An error occurred. Please try again later.']);
        }
    } else {
        error_log("Invalid action: " . $input['action']);
        http_response_code(400);
        echo json_encode(['error' => 'Invalid action.']);
    }
} else {
    error_log("Invalid request method.");
    http_response_code(405);
    echo json_encode(['error' => 'Invalid request method.']);
}
?>
