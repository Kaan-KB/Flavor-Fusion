<?php
session_start();

// Redirect to login page if user is not logged in
if (!isset($_SESSION['email'])) {
    $_SESSION['error'] = "You must be logged in to view this page.";
    header("Location: login.php");
    exit();
}

// Ensure role is set in session and it's admin
if (isset($_SESSION['role']) && $_SESSION['role'] === 'admin') {
    $role = 'Admin';
} else {
    $role = 'User'; // Default role or handle other roles as needed
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Profile</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <?php include 'nav.php'; ?>

    <div class="container">
        <h1>Welcome, <?php echo htmlspecialchars($_SESSION['email']); ?>!</h1>
        <p>Your role: <?php echo htmlspecialchars($role); ?></p>

        <!-- Debugging session information -->
        <div>
            <h2>Session Information</h2>
            <pre>
                <?php print_r($_SESSION); ?>
            </pre>
        </div>

        <h2>Your Favorite Recipes</h2>
        <div class="recipes-grid">
            <?php
            // Your existing code to display favorite recipes goes here
            ?>
        </div>
    </div>

</body>
</html>
