<?php
require_once __DIR__ . '/vendor/autoload.php';
use PhpAmqpLib\Connection\AMQPStreamConnection;
use PhpAmqpLib\Message\AMQPMessage;

if (!isset($_SESSION['email']) || $_SESSION['role'] !== 'admin') {
    header("Location: login.php");
    exit();
}

// Include session timeout management
include 'sessiontimeout.php';
include 'nav.php';
// RabbitMQ connection settings
$connection = new AMQPStreamConnection('18.207.17.153', 5672, 'MQServer', 'IT490');
$channel = $connection->channel();
$channel->queue_declare('admin_queue', false, false, false, false);

// Function to fetch table data
function fetchTableData() {
    global $channel;

    // Send a message to request data
    $msg = new AMQPMessage('', ['correlation_id' => uniqid(), 'reply_to' => 'admin_queue']);
    $channel->basic_publish($msg, '', 'admin_queue');
}

// Check if Fetch Table button is clicked
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['fetch_table'])) {
    fetchTableData();
}

// Callback function to handle RabbitMQ messages
$callback = function ($msg) {
    $users = json_decode($msg->body, true);
?>
<!DOCTYPE html>

<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Admin Panel</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
    <div class="container">
        <h1>Users Table</h1>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Email</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($users as $user): ?>
                <tr>
                    <td><?php echo $user['id']; ?></td>
                    <td><?php echo $user['email']; ?></td>
                    <td>
                        <a href="#">Edit</a> |
                        <a href="#">Delete</a>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>

    <!-- Bootstrap JS and dependencies -->
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
<?php
    // Acknowledge the message
    $msg->delivery_info['channel']->basic_ack($msg->delivery_info['delivery_tag']);
};

// Consume messages from admin_queue
$channel->basic_consume('admin_queue', '', false, false, false, false, $callback);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Admin Panel</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
    <div class="container">
        <h1>Users Table</h1>
        <form method="post">
            <button type="submit" class="btn btn-primary" name="fetch_table">Fetch Table</button>
        </form>
    </div>

    <!-- Bootstrap JS and dependencies -->
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
