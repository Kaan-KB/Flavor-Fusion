import json

import requests
import pika

# RabbitMQ connection parameters
rabbitmq_host = 'rabbitmq-elb-dad86311aae5d992.elb.us-east-1.amazonaws.com'    # RabbitMQ server address
rabbitmq_port = 5672               # RabbitMQ server port
rabbitmq_user = 'MQServer'         # RabbitMQ username
rabbitmq_password = 'IT490'        # RabbitMQ password
queue_name = 'api_sendback'            # RabbitMQ queue name
exchange_name = 'API_TEST'         # RabbitMQ exchange name
routing_key = 'testmesAPI'         # RabbitMQ routing key

# Fetch data from TheMealDB API
def getall():
    credentials = pika.PlainCredentials(rabbitmq_user, rabbitmq_password)
    parameters = pika.ConnectionParameters(rabbitmq_host, rabbitmq_port, '/', credentials)
    connection = pika.BlockingConnection(parameters)
    channel = connection.channel()
    channel.exchange_declare(exchange=exchange_name, exchange_type='direct', durable=True)
    channel.queue_declare(queue=queue_name, durable=False)
    channel.queue_bind(queue=queue_name, exchange=exchange_name, routing_key=routing_key)

    api_url = f"https://www.themealdb.com/api/json/v1/1/search.php?f=1"
    print(api_url)
    response = requests.get(api_url)
    data = response.json()
    truedata = json.dumps(data["meals"][0])
    channel.basic_publish(exchange=exchange_name, routing_key=routing_key, body=truedata)
    #have to do this because of one food that start with a number
    print(f" [x] Sent '{truedata}'")

    api_url = f"https://www.themealdb.com/api/json/v1/1/search.php?f="
    for x in range (26):
        print(api_url+chr(ord('a')+x))
        response = requests.get(api_url+chr(ord('a')+x))
        data = response.json()
        for z in data["meals"]:
            truedata = json.dumps(z)
            try:


                # Bind the queue to the exchange with the routing key

                channel.basic_publish(exchange=exchange_name, routing_key=routing_key, body=truedata)

                print(f" [x] Sent '{truedata}'")

                channel.close()
                connection.close()
            except pika.exceptions.AMQPError as e:
                print(f"Error connecting to RabbitMQ: {e}")
