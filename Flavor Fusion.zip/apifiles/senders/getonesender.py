import json

import requests
import pika

# RabbitMQ connection parameters
rabbitmq_host = 'rabbitmq-elb-dad86311aae5d992.elb.us-east-1.amazonaws.com'    # RabbitMQ server address
rabbitmq_port = 5672               # RabbitMQ server port
rabbitmq_user = 'MQServer'         # RabbitMQ username
rabbitmq_password = 'IT490'        # RabbitMQ password
queue_name = 'api_sendback'            # RabbitMQ queue name
exchange_name = 'API_TEST'      # RabbitMQ exchange name
routing_key = 'testmesAPI'     # RabbitMQ routing key

# Fetch data from TheMealDB API
def getone(mealID):
    credentials = pika.PlainCredentials(rabbitmq_user, rabbitmq_password)
    parameters = pika.ConnectionParameters(rabbitmq_host, rabbitmq_port, '/', credentials)
    connection = pika.BlockingConnection(parameters)
    channel = connection.channel()
    channel.exchange_declare(exchange=exchange_name, exchange_type='direct', durable=True)
    channel.queue_declare(queue=queue_name, durable=False)
    channel.queue_bind(queue=queue_name, exchange=exchange_name, routing_key=routing_key)
    api_url = f"https://www.themealdb.com/api/json/v1/1/lookup.php?i="
    print(api_url + mealID)
    try:
        response = requests.get(api_url + mealID)
        data = response.json()
        truedata = json.dumps(data["meals"])
        channel.basic_publish(exchange=exchange_name, routing_key=routing_key, body=truedata)
        print(f" [x] Sent '{truedata}'")
    except requests.RequestException as e:
        print(f"ERROR: API request failed - {e}")
    except pika.exceptions.AMQPError as e:
        print(f"ERROR: RabbitMQ error - {e}")
    except Exception as e:
        print(f"ERROR: An unexpected error occurred - {e}") 
