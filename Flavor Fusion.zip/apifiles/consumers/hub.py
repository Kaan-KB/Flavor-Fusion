import sys
import os
import json
import pika
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
import consumers.whattodo as whattodo

# RabbitMQ connection parameters
class hub:
    def __init__(self):
        self.rabbitmq_host = 'rabbitmq-elb-dad86311aae5d992.elb.us-east-1.amazonaws.com'
        self.rabbitmq_port = 5672
        self.rabbitmq_user = 'MQServer'
        self.rabbitmq_password = 'IT490'
        self.queue_name = 'api_queue'  # Ensure this matches your PHP script

        self.credentials = pika.PlainCredentials(self.rabbitmq_user, self.rabbitmq_password)
        self.parameters = pika.ConnectionParameters(self.rabbitmq_host, self.rabbitmq_port, '/', self.credentials)

    def callback(self,ch, method, properties, body):
        print(f" [x] Received from RabbitMQ: {body.decode()}")
        choice=f"{body.decode()}"
        
        sys.stdout.flush()
        try:
            x = json.loads(choice)
            print("json loaded")
        except json.JSONDecodeError as e:
            print(f"JSON decode error: {e}")
        whattodo.choice(x)
        ch.basic_ack(delivery_tag=method.delivery_tag)
    def main(self):
        try:
            print("Connecting to RabbitMQ...")
            connection = pika.BlockingConnection(self.parameters)
            channel = connection.channel()
            print("Connected to RabbitMQ")

            channel.queue_declare(queue= self.queue_name, durable=False)

            channel.basic_consume(queue= self.queue_name, on_message_callback=self.callback, auto_ack=False)

            print(" [*] Waiting for messages. To exit press CTRL+C")
            channel.start_consuming()

        except pika.exceptions.AMQPConnectionError as e:
            print(f"Failed to connect to RabbitMQ: {e}")
            sys.exit(1)
        except Exception as e:
            print(f"An error occurred: {e}")
            sys.exit(1)
