import sys
import os
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
import requests
import json
from senders.getallsender import getall
from senders.getonesender import getone
from senders.getcatsender import getcat
def choice(wtd):

    match wtd["method"]:
        case "getall":
            getall()
        case "getone":
            getone(wtd["data"])
        case "getcat":
            getcat(wtd["data"])
        case _:
            print("ERROR: No valid method was choosen change the method key")