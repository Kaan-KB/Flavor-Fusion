from consumers.whattodo import choice as simple
from senders.getonesender import getone
simple({"method":"getall",
      "data":"test"}
)