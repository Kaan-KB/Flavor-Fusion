import pika
import json
import sys
rabbitmq_host = 'rabbitmq-elb-dad86311aae5d992.elb.us-east-1.amazonaws.com'
rabbitmq_port = 5672
rabbitmq_user = 'MQServer'
rabbitmq_password = 'IT490'
queue_name = 'api__queue'  # Ensure this matches your queue name

credentials = pika.PlainCredentials(rabbitmq_user, rabbitmq_password)
parameters = pika.ConnectionParameters(rabbitmq_host, rabbitmq_port, '/', credentials)
connection = pika.BlockingConnection(parameters)
channel = connection.channel()
body={"method":"{}".format(sys.argv[1]),
      "data":"{}".format(sys.argv[2])}
tbody=json.dumps(body)
channel.queue_declare(queue=queue_name)
channel.basic_publish(exchange='', routing_key=queue_name, body=tbody)
print("Sent {}".format(tbody))

connection.close()
