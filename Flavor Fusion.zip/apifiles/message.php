<?php
$command=escapeshellcmd('python3 /home/ubuntu/apifiles/testsend.py '.$argv[1].' '.$argv[2]);
$str_output = shell_exec($command);
echo $command;
?>
