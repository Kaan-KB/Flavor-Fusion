#!/bin/bash
sudo systemctl daemon-reload
sudo systemctl start api_consumer.service
