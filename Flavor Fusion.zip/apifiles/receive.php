<?php

// Include the RabbitMQ PHP library
require_once __DIR__ . '/vendor/autoload.php'; // Include Composer's autoloader
use PhpAmqpLib\Connection\AMQPStreamConnection;

// RabbitMQ connection details
$rabbitmqHost = '18.207.17.153'; // Replace with RabbitMQ host
$rabbitmqPort = 5672; // Replace with RabbitMQ port
$rabbitmqUser = 'MQServer'; // Replace with RabbitMQ user
$rabbitmqPassword = 'IT490'; // Replace with RabbitMQ password
$queueName = 'INSERTCORRECTQUEUEHERE'; // Replace with your queue name

// Connect to RabbitMQ
$connection = new AMQPStreamConnection($rabbitmqHost, $rabbitmqPort, $rabbitmqUser, $rabbitmqPassword);
$channel = $connection->channel();

// Declare the queue
$channel->queue_declare($queueName, false, false, false, false);

echo " [*] Waiting for messages. To exit press CTRL+C\n";

// Callback function to handle incoming messages
$callback = function($msg) {
    echo " [x] Received from RabbitMQ: ", $msg->body, "\n";

    // Process the message (replace with actual logic)
    // Example: Save the message to a database, trigger another process, etc.

    // Acknowledge message received
    $msg->delivery_info['channel']->basic_ack($msg->delivery_info['delivery_tag']);
};

// Consume messages from queue
$channel->basic_consume($queueName, '', false, false, false, false, $callback);

// Wait for incoming messages
while($channel->is_consuming()) {
    $channel->wait();
}

// Close the channel and connection
$channel->close();
$connection->close();

?>