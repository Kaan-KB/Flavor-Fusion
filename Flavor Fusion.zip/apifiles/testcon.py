import pika
from consumers.hub import hub
rabbitmq_host = 'rabbitmq-elb-dad86311aae5d992.elb.us-east-1.amazonaws.com'
rabbitmq_port = 5672
rabbitmq_user = 'MQServer'
rabbitmq_password = 'IT490'

credentials = pika.PlainCredentials(rabbitmq_user, rabbitmq_password)
parameters = pika.ConnectionParameters(rabbitmq_host, rabbitmq_port, '/', credentials)

try:
    connection = pika.BlockingConnection(parameters)
    print("Successfully connected to RabbitMQ")
    connection.close()
except pika.exceptions.AMQPConnectionError as e:
    print(f"Failed to connect to RabbitMQ: {e}")
    exit()
#as soon as connection is good it will move to permenant consumer
#me making stuff up be like
consumer=hub()
consumer.main()
