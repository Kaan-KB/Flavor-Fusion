import pika
import sys,os
# RabbitMQ connection parameters
rabbitmq_host = '18.207.17.153'
rabbitmq_port = 5672
rabbitmq_user = 'MQServer'
rabbitmq_password = 'IT490'
queue_name = 'api_queue'  # Ensure this matches your PHP script

credentials = pika.PlainCredentials(rabbitmq_user, rabbitmq_password)
parameters = pika.ConnectionParameters(rabbitmq_host, rabbitmq_port, '/', credentials)

def callback(ch, method, properties, body):
    print(f" [x] Received from RabbitMQ: {body.decode()}")
    # Add your processing logic here

    # Acknowledge message received
    ch.basic_ack(delivery_tag=method.delivery_tag)

try:
    print("Connecting to RabbitMQ...")
    connection = pika.BlockingConnection(parameters)
    channel = connection.channel()
    print("Connected to RabbitMQ")

    channel.queue_declare(queue=queue_name, durable=False)

    channel.basic_consume(queue=queue_name, on_message_callback=callback, auto_ack=False)

    print(" [*] Waiting for messages. To exit press CTRL+C")
    channel.start_consuming()

except pika.exceptions.AMQPConnectionError as e:
    print(f"Failed to connect to RabbitMQ: {e}")
    sys.exit(1)
except Exception as e:
    print(f"An error occurred: {e}")
    sys.exit(1)
