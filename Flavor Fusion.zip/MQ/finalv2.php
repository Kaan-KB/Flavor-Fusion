<?php
require_once __DIR__ . '/vendor/autoload.php'; // Include Composer's autoloader

use PhpAmqpLib\Connection\AMQPStreamConnection;
use PhpAmqpLib\Message\AMQPMessage;

// RabbitMQ connection credentials
$rabbitmq_host = 'rabbitmq-elb-dad86311aae5d992.elb.us-east-1.amazonaws.com';
$rabbitmq_port = 5672;
$rabbitmq_user = 'MQServer';
$rabbitmq_password = 'IT490';
$heartbeat = 60; // Heartbeat interval in seconds
$timeout = 30; // Connection timeout in seconds

// MySQL database credentials
$mysql_host = 'Database-NLB-a57264455bbebb21.elb.us-east-1.amazonaws.com';
$mysql_user = 'IT490Database';
$mysql_password = 'IT490';
$mysql_database = 'Flavor';

// This establishes the RabbitMQ connection
$connection = new AMQPStreamConnection(
    $rabbitmq_host, 
    $rabbitmq_port, 
    $rabbitmq_user, 
    $rabbitmq_password, 
    '/', // vhost
    false, // insist
    'AMQPLAIN', // login method
    null, // login response
    'en_US', // locale
    $timeout, // connection timeout
    $timeout, // read/write timeout
    null, // context
    true, // keepalive
    $heartbeat // heartbeat
);

$channel = $connection->channel();

// Where the queues are declared
$channel->queue_declare('register_queue', false, true, false, false);
$channel->queue_declare('login_queue', false, false, false, false);
$channel->queue_declare('APIqueue', false, false, false, false);// used it to populate the database with the recipes

// echos a message to the terminal
echo "Waiting for messages. To exit press CTRL+C\n";

// Callback function for registration and login messages, use of switch case, checks the action type for 'register' and 'login'
//this callback handles login_queue, and register_queue
$callback = function ($msg) use ($mysql_host, $mysql_user, $mysql_password, $mysql_database, $channel) {
    // Print the received message
    echo "Received message: " . $msg->body . "\n";
    
    // for decoding the data
    $data = json_decode($msg->body, true);

    //checks for missing data
    if (!isset($data['action'], $data['email'], $data['password'])) {
        echo "Invalid message format or missing email/password\n";
        return;
    }
 

    $type = $data['action'];

    // Connect to MySQL database
    $mysqli = new mysqli($mysql_host, $mysql_user, $mysql_password, $mysql_database);
    if ($mysqli->connect_error) {
        error_log('Connect Error (' . $mysqli->connect_errno . ') ' . $mysqli->connect_error);
        echo "Connect Error (" . $mysqli->connect_errno . ") " . $mysqli->connect_error . "\n";
        return;
    }

    $response = ['status' => 'fail'];

    switch ($type) {
        case 'register': // code for registration
            echo "Processing registration\n";
            $username = $mysqli->real_escape_string($data['username']);
            $firstname = $mysqli->real_escape_string($data['first_name']);
            $lastname = $mysqli->real_escape_string($data['last_name']);
            $email = $mysqli->real_escape_string($data['email']);            
            $password = password_hash($data['password'], PASSWORD_DEFAULT);
        
            try {
                $query = "START TRANSACTION;
                          INSERT INTO users (email, password) VALUES ('$email', '$password');
                          SET @userid = LAST_INSERT_ID();
                          INSERT INTO assignrole (id, rolesid) VALUES (@userid, 2);
                          INSERT INTO newname (user_id, username, first_name, last_name) VALUES (@userid, '$username', '$firstname', '$lastname');
                          COMMIT;";
                
                if ($mysqli->multi_query($query)) {
                    // Process all queries
                    do {
                        if ($result = $mysqli->store_result()) {
                            $result->free();
                        }
                    } while ($mysqli->next_result());
                    
                    // Check for any errors
                    if ($mysqli->errno) {
                        throw new Exception($mysqli->error, $mysqli->errno);
                    }
        
                    $response['status'] = 'success';
                    echo "User registered successfully\n";
                } else {
                    throw new Exception($mysqli->error, $mysqli->errno);
                }
            } catch (Exception $e) {
                if ($e->getCode() == 1062) {
                    $response['status'] = 'fail';
                    $response['error'] = 'Duplicate entry';
                    $response['message'] = 'The email address is already registered.';
                    echo "Duplicate entry: " . $email . "\n";
                } else {
                    $response['error'] = $e->getMessage();
                    error_log('MySQL Error: ' . $e->getMessage());
                    echo "MySQL Error: " . $e->getMessage() . "\n";
                }
            }
            break;

        case 'login': //code for login
            echo "Processing login\n";
            $email = $mysqli->real_escape_string($data['email']);
            $password = $data['password']; // No need to hash here as we'll verify against the stored hash
            //checks user credentials and retrieves the users role.
            $query = "SELECT u.id, u.email, u.password, r.roles 
                      FROM users u
                      LEFT JOIN assignrole ar ON u.id = ar.id
                      LEFT JOIN roles r ON ar.rolesid = r.idroles
                      WHERE u.email = ?";
            $stmt = $mysqli->prepare($query);
            $stmt->bind_param("s", $email);
            $stmt->execute();
            $result = $stmt->get_result();

            if ($result && $result->num_rows > 0) {
                $row = $result->fetch_assoc();
                // For Verifying password
                if (password_verify($password, $row['password'])) {
                    $response = [
                        'status' => 'success',
                        'user_id' => $row['id'],
                        'email' => $row['email'],
                        'role' => $row['roles']
                    ];
                    echo "Login successful\n";
                } else {
                    $response = ['status' => 'fail', 'error' => 'Invalid password'];
                    echo "Invalid password\n";
                }
            } else {
                $response = ['status' => 'fail', 'error' => 'Email not found'];
                echo "Email not found\n";
            }

            $stmt->close();
            break;

        default:
            $response['error'] = 'Invalid request type';
            echo "Invalid request type\n";
            break;
    }

    $mysqli->close();

    // Prepare response message
    $responseMsg = new AMQPMessage(
        json_encode($response),
        ['correlation_id' => $msg->has('correlation_id') ? $msg->get('correlation_id') : null]
    );

    if ($msg->has('reply_to')) {
        $msg->delivery_info['channel']->basic_publish($responseMsg, '', $msg->get('reply_to'));
    } else {
        $msg->delivery_info['channel']->basic_publish($responseMsg, '');
    }
};

$apiCallback = function ($msg) use ($mysql_host, $mysql_user, $mysql_password, $mysql_database, $channel) {
    echo "Received APIqueue message: " . $msg->body . "\n";

    // Convert JSON string to array
    $data = json_decode($msg->body, true);

    // Check if JSON decoding was successful
    if (json_last_error() !== JSON_ERROR_NONE) {
        echo "Error decoding JSON: " . json_last_error_msg() . "\n";
        return;
    }

    // Ensure all expected keys exist in the JSON data
    $expected_keys = ['idMeal', 'strMeal', 'strDrinkAlternate', 'strCategory', 'strArea', 'strInstructions', 'strMealThumb',
                      'strTags', 'strYoutube', 'strIngredient1', 'strIngredient2', 'strIngredient3', 'strIngredient4',
                      'strIngredient5', 'strIngredient6', 'strIngredient7', 'strIngredient8', 'strIngredient9',
                      'strIngredient10', 'strIngredient11', 'strIngredient12', 'strIngredient13', 'strIngredient14',
                      'strIngredient15', 'strIngredient16', 'strIngredient17', 'strIngredient18', 'strIngredient19',
                      'strIngredient20', 'strMeasure1', 'strMeasure2', 'strMeasure3', 'strMeasure4', 'strMeasure5',
                      'strMeasure6', 'strMeasure7', 'strMeasure8', 'strMeasure9', 'strMeasure10', 'strMeasure11',
                      'strMeasure12', 'strMeasure13', 'strMeasure14', 'strMeasure15', 'strMeasure16', 'strMeasure17',
                      'strMeasure18', 'strMeasure19', 'strMeasure20', 'strSource', 'strImageSource',
                      'strCreativeCommonsConfirmed', 'dateModified'];

    foreach ($expected_keys as $key) {
        if (!array_key_exists($key, $data)) {
            echo "'$key' key not found in the JSON data\n";
            return;
        }
    }

    // Connect to MySQL database
    $mysqli = new mysqli($mysql_host, $mysql_user, $mysql_password, $mysql_database);
    if ($mysqli->connect_error) {
        error_log('Connect Error (' . $mysqli->connect_errno . ') ' . $mysqli->connect_error);
        echo "Connect Error (" . $mysqli->connect_errno . ") " . $mysqli->connect_error . "\n";
        return;
    }

    // Use INSERT IGNORE to avoid duplicate entries
    $query = "INSERT IGNORE INTO meals (
        idMeal, strMeal, strDrinkAlternate, strCategory, strArea, strInstructions, strMealThumb, strTags, strYoutube,
        strIngredient1, strIngredient2, strIngredient3, strIngredient4, strIngredient5, strIngredient6, strIngredient7,
        strIngredient8, strIngredient9, strIngredient10, strIngredient11, strIngredient12, strIngredient13, strIngredient14,
        strIngredient15, strIngredient16, strIngredient17, strIngredient18, strIngredient19, strIngredient20, 
        strMeasure1, strMeasure2, strMeasure3, strMeasure4, strMeasure5, strMeasure6, strMeasure7, strMeasure8, 
        strMeasure9, strMeasure10, strMeasure11, strMeasure12, strMeasure13, strMeasure14, strMeasure15, strMeasure16, 
        strMeasure17, strMeasure18, strMeasure19, strMeasure20, strSource, strImageSource, strCreativeCommonsConfirmed, dateModified
    ) VALUES (
        ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

    // Prepare statement and bind parameters
    $stmt = $mysqli->prepare($query);
    
    if (!$stmt) {
        echo "Error preparing SQL statement: " . $mysqli->error . "\n";
        return;
    }
    
    // Bind parameters conditionally, handling null values
    $stmt->bind_param(
        "sssssssssssssssssssssssssssssssssssssssssssssssssssss",
        $data['idMeal'], $data['strMeal'], $data['strDrinkAlternate'], $data['strCategory'], $data['strArea'],
        $data['strInstructions'], $data['strMealThumb'], $data['strTags'], $data['strYoutube'],
        $data['strIngredient1'], $data['strIngredient2'], $data['strIngredient3'], $data['strIngredient4'],
        $data['strIngredient5'], $data['strIngredient6'], $data['strIngredient7'], $data['strIngredient8'],
        $data['strIngredient9'], $data['strIngredient10'], $data['strIngredient11'], $data['strIngredient12'],
        $data['strIngredient13'], $data['strIngredient14'], $data['strIngredient15'], $data['strIngredient16'],
        $data['strIngredient17'], $data['strIngredient18'], $data['strIngredient19'], $data['strIngredient20'],
        $data['strMeasure1'], $data['strMeasure2'], $data['strMeasure3'], $data['strMeasure4'], $data['strMeasure5'],
        $data['strMeasure6'], $data['strMeasure7'], $data['strMeasure8'], $data['strMeasure9'], $data['strMeasure10'],
        $data['strMeasure11'], $data['strMeasure12'], $data['strMeasure13'], $data['strMeasure14'], $data['strMeasure15'],
        $data['strMeasure16'], $data['strMeasure17'], $data['strMeasure18'], $data['strMeasure19'], $data['strMeasure20'],
        $data['strSource'], $data['strImageSource'], $data['strCreativeCommonsConfirmed'], $data['dateModified']
    );
    
    // Execute statement
    if ($stmt->execute()) {
        echo "Inserted new meal into database\n";
    } else {
        echo "Error inserting meal: " . $stmt->error . "\n";
    }
    
    // Close statement and database connection
    $stmt->close();
    $mysqli->close();
};

// Consume messages from register_queue and login_queue
$channel->basic_consume('register_queue', '', false, true, false, false, $callback);
$channel->basic_consume('login_queue', '', false, true, false, false, $callback);

// Consume messages from APIqueue
$channel->basic_consume('APIqueue', '', false, true, false, false, $apiCallback);

// Wait for incoming messages
while ($channel->is_consuming()) {
    $channel->wait();
}

// Closes the RabbitMQ connection
$channel->close();
$connection->close();
