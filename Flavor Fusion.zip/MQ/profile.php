<?php
require_once __DIR__ . '/vendor/autoload.php';
use PhpAmqpLib\Connection\AMQPStreamConnection;
use PhpAmqpLib\Message\AMQPMessage;

// RabbitMQ connection settings
$rabbitmq_host = 'rabbitmq-elb-dad86311aae5d992.elb.us-east-1.amazonaws.com';
$rabbitmq_port = 5672;
$rabbitmq_user = 'MQServer';
$rabbitmq_password = 'IT490';
$exchange_name = 'user_profiles';
$user_profiles_queue = 'favorites_queue';
$responseQueue = 'response_queue';

// MySQL database settings
$mysql_host = 'Database-NLB-a57264455bbebb21.elb.us-east-1.amazonaws.com';
$mysql_user = 'IT490Database';
$mysql_password = 'IT490';
$mysql_database = 'Flavor';

$mysqli = new mysqli($mysql_host, $mysql_user, $mysql_password, $mysql_database);

if ($mysqli->connect_errno) {
    echo "Failed to connect to MySQL: " . $mysqli->connect_error;
    exit();
}

$connection = new AMQPStreamConnection($rabbitmq_host, $rabbitmq_port, $rabbitmq_user, $rabbitmq_password);
$channel = $connection->channel();

$channel->exchange_declare($exchange_name, 'direct', false, true, false);
$channel->queue_declare($user_profiles_queue, false, true, false, false);
$channel->queue_bind($user_profiles_queue, $exchange_name);

function sendErrorResponse($channel, $responseQueue, $errorMessage, $correlationId, $replyTo) {
    $msg = new AMQPMessage(json_encode(['error' => $errorMessage]), [
        'correlation_id' => $correlationId
    ]);
    $channel->basic_publish($msg, '', $replyTo);
}

$callback = function ($msg) use ($mysqli, $channel, $responseQueue) {
    $requestData = json_decode($msg->body, true);
    $userEmail = $requestData['userEmail'];
    $limit = isset($requestData['limit']) ? (int)$requestData['limit'] : 10;
    $offset = isset($requestData['offset']) ? (int)$requestData['offset'] : 0;
    $correlationId = $msg->get('correlation_id');
    $replyTo = $msg->get('reply_to');

    try {
        // Fetch favorite recipes from MySQL with pagination
        $sql = "SELECT f.idmeal AS idMeal, m.strmealthumb AS picture, m.strmeal AS strMeal
                FROM fav_new f
                JOIN meals m ON f.idmeal = m.idMeal
                WHERE f.useremail = ?
                LIMIT ? OFFSET ?";
        $stmt = $mysqli->prepare($sql);
        if (!$stmt) {
            sendErrorResponse($channel, $responseQueue, 'Database query error', $correlationId, $replyTo);
            return;
        }
        $stmt->bind_param("sii", $userEmail, $limit, $offset);
        $stmt->execute();
        $result = $stmt->get_result();

        $favorites = [];
        while ($row = $result->fetch_assoc()) {
            $favorites[] = $row;
        }

        $stmt->close();

        $responseMsg = new AMQPMessage(json_encode($favorites), [
            'correlation_id' => $correlationId
        ]);
        $channel->basic_publish($responseMsg, '', $replyTo);
    } catch (\Exception $e) {
        echo "Exception occurred while processing message: " . $e->getMessage();
        error_log("Exception occurred while processing message: " . $e->getMessage());
    }
};

// Consume messages from the queue 'user_profiles'
$channel->basic_consume($user_profiles_queue, '', false, true, false, false, $callback);

echo " [*] Waiting for messages. To exit press CTRL+C\n";
// Listen for incoming messages
while ($channel->is_consuming()) {
    $channel->wait();
}

// Close MySQL and RabbitMQ connections
$mysqli->close();
$channel->close();
$connection->close();
?>
