<?php
require_once __DIR__ . '/vendor/autoload.php';

use PhpAmqpLib\Connection\AMQPStreamConnection;
use PhpAmqpLib\Message\AMQPMessage;

// RabbitMQ connection settings
$rabbitmq_host = 'rabbitmq-elb-dad86311aae5d992.elb.us-east-1.amazonaws.com';
$rabbitmq_port = 5672;
$rabbitmq_user = 'MQServer';
$rabbitmq_password = 'IT490';
$queue_name = 'recipe_fav'; // Queue for receiving favorite actions

// MySQL database settings
$mysql_host = 'Database-NLB-a57264455bbebb21.elb.us-east-1.amazonaws.com';
$mysql_user = 'IT490Database';
$mysql_password = 'IT490';
$mysql_database = 'Flavor';

$connection = new AMQPStreamConnection($rabbitmq_host, $rabbitmq_port, $rabbitmq_user, $rabbitmq_password);
$channel = $connection->channel();

$channel->queue_declare($queue_name, false, true, false, false);

$mysqli = new mysqli($mysql_host, $mysql_user, $mysql_password, $mysql_database);

if ($mysqli->connect_errno) {
    echo "Failed to connect to MySQL: " . $mysqli->connect_error;
    exit();
}

function sendErrorResponse($channel, $errorMessage, $correlationId, $replyTo) {
    $msg = new AMQPMessage(json_encode(['error' => $errorMessage]), [
        'correlation_id' => $correlationId
    ]);
    $channel->basic_publish($msg, '', $replyTo);
}

$callback = function ($msg) use ($mysqli, $channel) {
    echo " [x] Received ", $msg->body, "\n";

    $requestData = json_decode($msg->body, true);
    $recipeId = $requestData['idMeal'];
    $email = $requestData['email'];
    $isFavorite = $requestData['isFavorite'];
    $correlationId = $msg->get('correlation_id');
    $replyTo = $msg->get('reply_to');
    $action = $requestData['action'];

    $fetchSql = "SELECT strmealthumb FROM meals WHERE idMeal = ?";
    $fetchStmt = $mysqli->prepare($fetchSql);
    if (!$fetchStmt) {
        throw new Exception("Database query error: " . $mysqli->error);
    }
    $fetchStmt->bind_param("s", $recipeId);
    $fetchStmt->execute();
    $fetchStmt->bind_result($strmealthumb);
    $fetchStmt->fetch();
    $fetchStmt->close();

    // Perform favorite/unfavorite action (update database)
    try {
        if ($isFavorite) {
            // Insert or update if favorite
            $insertSql = "INSERT INTO fav_new (idmeal, useremail, is_favorite, strmealthumb) VALUES (?, ?, ?, ?)";
            $insertStmt = $mysqli->prepare($insertSql);
            if (!$insertStmt) {
                throw new Exception("Database query error: " . $mysqli->error);
            }
            $insertStmt->bind_param("isss", $recipeId, $email, $isFavorite, $strmealthumb);
            $insertStmt->execute();
            $insertStmt->close();
        } else {
            // Delete if unfavorite
            $deleteSql = "DELETE FROM fav_new WHERE idmeal = ? AND useremail = ?";
            $deleteStmt = $mysqli->prepare($deleteSql);
            if (!$deleteStmt) {
                throw new Exception("Database query error: " . $mysqli->error);
            }
            $deleteStmt->bind_param("ss", $recipeId, $email);
            $deleteStmt->execute();
            $deleteStmt->close();
        }

        $response = ['success' => true];
        $responseMsg = new AMQPMessage(json_encode($response), [
            'correlation_id' => $correlationId
        ]);
        $channel->basic_publish($responseMsg, '', $replyTo);

    } catch (Exception $e) {
        sendErrorResponse($channel, $e->getMessage(), $correlationId, $replyTo);
        error_log("MySQL Query Error: " . $mysqli->error);

    }

    $msg->delivery_info['channel']->basic_ack($msg->delivery_info['delivery_tag']);
};

echo " [*] Waiting for messages. To exit press CTRL+C\n";
$channel->basic_consume($queue_name, '', false, false, false, false, $callback);

while ($channel->is_consuming()) {
    $channel->wait();
}

$mysqli->close();
$channel->close();
$connection->close();
?>
