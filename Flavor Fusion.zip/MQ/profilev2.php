<?php
require_once __DIR__ . '/vendor/autoload.php';
use PhpAmqpLib\Connection\AMQPStreamConnection;
use PhpAmqpLib\Message\AMQPMessage;

// RabbitMQ connection settings
$rabbitmq_host = 'rabbitmq-elb-dad86311aae5d992.elb.us-east-1.amazonaws.com';
$rabbitmq_port = 5672;
$rabbitmq_user = 'MQServer';
$rabbitmq_password = 'IT490';
$exchange_name = 'user_profiles';
$user_profiles_queue = 'favorites_queue';
$responseQueue = 'response_queue';
$user_info_queue = 'user_info';

// MySQL database settings
$mysql_host = 'Database-NLB-a57264455bbebb21.elb.us-east-1.amazonaws.com';
$mysql_user = 'IT490Database';
$mysql_password = 'IT490';
$mysql_database = 'Flavor';

// Establish MySQL connection
$mysqli = new mysqli($mysql_host, $mysql_user, $mysql_password, $mysql_database);

// Check MySQL connection
if ($mysqli->connect_errno) {
    echo "Failed to connect to MySQL: " . $mysqli->connect_error;
    exit();
}

// Establish RabbitMQ connection and channel
$connection = new AMQPStreamConnection($rabbitmq_host, $rabbitmq_port, $rabbitmq_user, $rabbitmq_password);
$channel = $connection->channel();

// Declare exchange and queues
$channel->exchange_declare($exchange_name, 'direct', false, true, false);
$channel->queue_declare($user_profiles_queue, false, true, false, false);
$channel->queue_declare($user_info_queue, false, true, false, false); // Declare the new queue
$channel->queue_bind($user_profiles_queue, $exchange_name);
$channel->queue_bind($user_info_queue, $exchange_name); // Bind the new queue to the exchange

// Function to send error responses
function sendErrorResponse($channel, $replyTo, $errorMessage, $correlationId) {
    $msg = new AMQPMessage(json_encode(['error' => $errorMessage]), [
        'correlation_id' => $correlationId
    ]);
    $channel->basic_publish($msg, '', $replyTo);
}

// Callback function to handle favorite recipes requests
$favoritesCallback = function ($msg) use ($mysqli, $channel) {
    $requestData = json_decode($msg->body, true);
    $userEmail = $requestData['userEmail'];
    $limit = isset($requestData['limit']) ? (int)$requestData['limit'] : 10;
    $offset = isset($requestData['offset']) ? (int)$requestData['offset'] : 0;
    $correlationId = $msg->get('correlation_id');
    $replyTo = $msg->get('reply_to');

    try {
        // Fetch favorite recipes from MySQL with pagination
        $sql = "SELECT f.idmeal AS idMeal, m.strmealthumb AS picture, m.strmeal AS strMeal
                FROM fav_new f
                JOIN meals m ON f.idmeal = m.idMeal
                WHERE f.useremail = ?
                LIMIT ? OFFSET ?";
        $stmt = $mysqli->prepare($sql);
        if (!$stmt) {
            sendErrorResponse($channel, $replyTo, 'Database query error', $correlationId);
            return;
        }
        $stmt->bind_param("sii", $userEmail, $limit, $offset);
        $stmt->execute();
        $result = $stmt->get_result();

        $favorites = [];
        while ($row = $result->fetch_assoc()) {
            $favorites[] = $row;
        }

        $stmt->close();

        // Send response back to frontend
        $responseMsg = new AMQPMessage(json_encode($favorites), [
            'correlation_id' => $correlationId
        ]);
        $channel->basic_publish($responseMsg, '', $replyTo);
    } catch (\Exception $e) {
        echo "Exception occurred while processing message: " . $e->getMessage();
        error_log("Exception occurred while processing message: " . $e->getMessage());
        sendErrorResponse($channel, $replyTo, 'Exception occurred', $correlationId);
    }
};

// Callback function to handle user profile requests
$userInfoCallback = function ($msg) use ($mysqli, $channel) {
    $requestData = json_decode($msg->body, true);
    $userEmail = $requestData['userEmail'];
    $correlationId = $msg->get('correlation_id');
    $replyTo = $msg->get('reply_to');

    try {
        // Fetch user info from MySQL
        $sql = "USE Flavor;
        SELECT u.email, n.username, n.first_name, n.last_name
        FROM users u
        JOIN newname n ON u.id = n.user_id
        WHERE u.email = ?;";
        $stmt = $mysqli->prepare($sql);
        if (!$stmt) {
            sendErrorResponse($channel, $replyTo, 'Database query error', $correlationId);
            return;
        }
        $stmt->bind_param("s", $userEmail);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($row = $result->fetch_assoc()) {
            $userInfo = [
                'email' => $row['email'],
                'username' => $row['username'],
                'first_name' => $row['first_name'],
                'last_name' => $row['last_name']
            ];

            // Send response back to frontend
            $responseMsg = new AMQPMessage(json_encode($userInfo), [
                'correlation_id' => $correlationId
            ]);
            $channel->basic_publish($responseMsg, '', $replyTo);
        } else {
            sendErrorResponse($channel, $replyTo, 'User not found', $correlationId);
        }

        $stmt->close();
    } catch (\Exception $e) {
        echo "Exception occurred while processing message: " . $e->getMessage();
        error_log("Exception occurred while processing message: " . $e->getMessage());
        sendErrorResponse($channel, $replyTo, 'Exception occurred', $correlationId);
    }
};

// Consume messages from the queue 'user_profiles' for favorite recipes
$channel->basic_consume($user_profiles_queue, '', false, true, false, false, $favoritesCallback);

// Consume messages from the new queue 'user_info_queue' for user info
$channel->basic_consume($user_info_queue, '', false, true, false, false, $userInfoCallback);

echo " [*] Waiting for messages. To exit press CTRL+C\n";
// Listen for incoming messages
while ($channel->is_consuming()) {
    $channel->wait();
}

// Close MySQL and RabbitMQ connections
$mysqli->close();
$channel->close();
$connection->close();
?>
