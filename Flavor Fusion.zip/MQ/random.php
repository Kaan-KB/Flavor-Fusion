<?php

require_once __DIR__ . '/vendor/autoload.php'; // Autoload dependencies

use PhpAmqpLib\Connection\AMQPStreamConnection;
use PhpAmqpLib\Message\AMQPMessage;

// RabbitMQ connection credentials
$dsn = 'mysql:host=Database-NLB-a57264455bbebb21.elb.us-east-1.amazonaws.com;dbname=Flavor;charset=utf8mb4';
$username = 'IT490Database';
$password = 'IT490';

// These are the credentials for MYSQL DB
$rabbitmqHost = 'rabbitmq-elb-dad86311aae5d992.elb.us-east-1.amazonaws.com';
$rabbitmqPort = 5672;
$rabbitmqUser = 'MQServer';
$rabbitmqPassword = 'IT490';
$queueName = 'random_meal_queue';

try {
    // Establish MySQL connection
    $pdo = new PDO($dsn, $username, $password, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    ]);

    echo "Connected to MySQL successfully.\n";

    // Establishes connection with RabbitMQ through AMQP 
    $connection = new AMQPStreamConnection($rabbitmqHost, $rabbitmqPort, $rabbitmqUser, $rabbitmqPassword);
    $channel = $connection->channel();

    $channel->queue_declare($queueName, false, true, false, false);

    // Callback function used for processing incoming messages
    $callback = function ($msg) use ($pdo, $channel) {
        try {
            $data = json_decode($msg->body, true);
            $category = isset($data['category']) ? $data['category'] : null;
            
            if ($category) {
                $sql = "SELECT * FROM meals
                        WHERE strCategory = :category
                        ORDER BY RAND()
                        LIMIT 1";
                $stmt = $pdo->prepare($sql);
                $stmt->execute([':category' => $category]);
                echo "Query executed for category: $category\n"; 
            } else {
                $sql = "SELECT * FROM meals ORDER BY RAND() LIMIT 1";
                $stmt = $pdo->query($sql);
                echo "Query executed for a random meal.\n"; 
            }

            $meal = $stmt->fetch();

            if ($meal) {
                // Include idMeal in the response
                $responseData = [
                    'idMeal' => $meal['idMeal'],
                    'strMeal' => $meal['strMeal'],
                    'strCategory' => $meal['strCategory'],
                    'strArea' => $meal['strArea'],
                    'strMealThumb' => $meal['strMealThumb'],
                ];

                echo "Meal found: " . json_encode($responseData) . "\n"; 
            } else {
                $responseData = ['error' => 'No meal found'];
                echo "No meal found for the given query.\n"; 
            }

            $response = new AMQPMessage(json_encode($responseData), [
                'correlation_id' => $msg->get('correlation_id'),
                'reply_to' => $msg->get('reply_to')
            ]);

            $channel->basic_publish($response, '', $msg->get('reply_to'));
            echo "Response sent.\n"; // Debugging message

            $channel->basic_ack($msg->delivery_info['delivery_tag']);

        } catch (Exception $e) {
            error_log("Error processing message: " . $e->getMessage());
            echo "Error processing message: " . $e->getMessage() . "\n";

            $errorResponse = new AMQPMessage(json_encode(['error' => 'Internal server error']), [
                'correlation_id' => $msg->get('correlation_id'),
                'reply_to' => $msg->get('reply_to')
            ]);

            $channel->basic_publish($errorResponse, '', $msg->get('reply_to'));

            $channel->basic_ack($msg->delivery_info['delivery_tag']);
        }
    };

    $channel->basic_consume($queueName, '', false, false, false, false, $callback);

    echo " [*] Waiting for messages. To exit press CTRL+C\n"; // Debugging message

    while ($channel->is_consuming()) {
        $channel->wait();
    }

    $channel->close();
    $connection->close();
    $pdo = null;  

} catch (PDOException $e) {
    error_log("MySQL Connection Error: " . $e->getMessage());
    echo "MySQL Connection Error: " . $e->getMessage() . "\n";
} catch (Exception $e) {
    error_log("General Error: " . $e->getMessage());
    echo "General Error: " . $e->getMessage() . "\n";
}

?>
