<?php
require_once __DIR__ . '/vendor/autoload.php';
use PhpAmqpLib\Connection\AMQPStreamConnection;
use PhpAmqpLib\Message\AMQPMessage;

// RabbitMQ connection settings
$rabbitmq_host = 'rabbitmq-elb-dad86311aae5d992.elb.us-east-1.amazonaws.com';
$rabbitmq_port = 5672;
$rabbitmq_user = 'MQServer';
$rabbitmq_password = 'IT490';
$like_queue_name = 'like_count';

// MySQL database settings
$mysql_host = 'Database-NLB-a57264455bbebb21.elb.us-east-1.amazonaws.com';
$mysql_user = 'IT490Database';
$mysql_password = 'IT490';
$mysql_database = 'Flavor';

$mysqli = new mysqli($mysql_host, $mysql_user, $mysql_password, $mysql_database);

if ($mysqli->connect_errno) {
    echo "Failed to connect to MySQL: " . $mysqli->connect_error;
    exit();
}

$connection = new AMQPStreamConnection($rabbitmq_host, $rabbitmq_port, $rabbitmq_user, $rabbitmq_password);
$channel = $connection->channel();

$channel->queue_declare($like_queue_name, false, true, false, false);

function sendErrorResponse($channel, $errorMessage, $correlationId, $replyTo) {
    $msg = new AMQPMessage(json_encode(['error' => $errorMessage]), [
        'correlation_id' => $correlationId
    ]);
    $channel->basic_publish($msg, '', $replyTo);
}function sendResponse($channel, $responseMessage, $correlationId, $replyTo) {
    $msg = new AMQPMessage(json_encode(['' => $responseMessage]), [
        'correlation_id' => $correlationId
    ]);
    $channel->basic_publish($msg, '', $replyTo);
}


$callback = function ($msg) use ($mysqli, $channel) {
    echo " [x] Received ", $msg->body, "\n";
    $requestData = json_decode($msg->body, true);
    $recipeId = $requestData['idMeal'];
    $correlationId = $msg->get('correlation_id');
    $replyTo = $msg->get('reply_to');

    $sql = "SELECT idmeal, SUM(like_count) AS total_likes FROM newlike WHERE idmeal = ? GROUP BY idmeal";
    $stmt = $mysqli->prepare($sql);
    if (!$stmt) {
        sendErrorResponse($channel, 'Database query error', $correlationId, $replyTo);
        return;
    }
    $stmt->bind_param("i", $recipeId);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $likeData = $result->fetch_assoc();
        $likeCount = $likeData['total_likes'];

        $responseMsg = new AMQPMessage(json_encode(['like_count' => $likeCount]), [
            'correlation_id' => $correlationId
        ]);
        echo " [x] Sending ", json_encode(['like_count' => $likeCount]), "\n";
        $channel->basic_publish($responseMsg, '', $replyTo);
    } else {
        sendResponse($channel, '0', $correlationId, $replyTo);
    }

    $stmt->close();
};


$channel->basic_consume($like_queue_name, '', false, true, false, false, $callback);

echo " [*] Waiting for messages. To exit press CTRL+C\n";

while ($channel->is_consuming()) {
    $channel->wait();
}

$mysqli->close();

$channel->close();
$connection->close();
?>
