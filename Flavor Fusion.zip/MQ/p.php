<?php
require_once __DIR__ . '/vendor/autoload.php';

use PhpAmqpLib\Connection\AMQPStreamConnection;
use PhpAmqpLib\Message\AMQPMessage;

$rabbitmq_host = 'rabbitmq-elb-dad86311aae5d992.elb.us-east-1.amazonaws.com';
$rabbitmq_port = 5672;
$rabbitmq_user = 'MQServer';
$rabbitmq_password = 'IT490';
$user_info_queue = 'user_info';  // Changed queue name to 'user_info"
$responseQueue = 'response_queue';

$mysql_host = 'Database-NLB-a57264455bbebb21.elb.us-east-1.amazonaws.com';
$mysql_user = 'IT490Database';
$mysql_password = 'IT490';
$mysql_database = 'Flavor';

$mysqli = new mysqli($mysql_host, $mysql_user, $mysql_password, $mysql_database);
if ($mysqli->connect_errno) {
    echo "Failed to connect to MySQL: " . $mysqli->connect_error . "\n";
    exit();
}
echo "MySQL connection established.\n";

$connection = new AMQPStreamConnection($rabbitmq_host, $rabbitmq_port, $rabbitmq_user, $rabbitmq_password);
$channel = $connection->channel();
echo "RabbitMQ connection established.\n";

$channel->queue_declare($user_info_queue, false, true, false, false);

function sendErrorResponse($channel, $responseQueue, $errorMessage, $correlationId, $replyTo) {
    $msg = new AMQPMessage(json_encode(['error' => $errorMessage]), [
        'correlation_id' => $correlationId
    ]);
    $channel->basic_publish($msg, '', $replyTo);
}

$callback = function ($msg) use ($mysqli, $channel, $responseQueue) {
    echo "Callback function executed.\n";
    $requestData = json_decode($msg->body, true);
    $userEmail = $requestData['userEmail'];
    $correlationId = $msg->get('correlation_id');
    $replyTo = $msg->get('reply_to');

    try {
        $sql = "SELECT u.email, n.username, n.first_name, n.last_name
                FROM users u
                JOIN newname n ON u.id = n.user_id
                WHERE u.email = ?";
        $stmt = $mysqli->prepare($sql);
        if (!$stmt) {
            sendErrorResponse($channel, $responseQueue, 'Database query error', $correlationId, $replyTo);
            return;
        }
        $stmt->bind_param("s", $userEmail);
        $stmt->execute();
        $result = $stmt->get_result();

        $userProfile = $result->fetch_assoc();
        
        $stmt->close();

        $responseMsg = new AMQPMessage(json_encode($userProfile), [
            'correlation_id' => $correlationId
        ]);
        $channel->basic_publish($responseMsg, '', $replyTo);
    } catch (\Exception $e) {
        echo "Exception occurred while processing message: " . $e->getMessage() . "\n";
        error_log("Exception occurred while processing message: " . $e->getMessage());
        sendErrorResponse($channel, $responseQueue, 'Internal server error', $correlationId, $replyTo);
    }
};

$channel->basic_consume($user_info_queue, '', false, true, false, false, $callback);

echo " [*] Waiting for messages. To exit press CTRL+C\n";
while ($channel->is_consuming()) {
    $channel->wait();
}

// Close MySQL and RabbitMQ connections
$mysqli->close();
$channel->close();
$connection->close();
?>
