<?php
require_once __DIR__ . '/vendor/autoload.php';

use PhpAmqpLib\Connection\AMQPStreamConnection;
use PhpAmqpLib\Message\AMQPMessage;
use PhpAmqpLib\Channel\AMQPChannel;

// RabbitMQ connection credentials
$rabbitmq_host = 'rabbitmq-elb-dad86311aae5d992.elb.us-east-1.amazonaws.com';
$rabbitmq_port = 5672;
$rabbitmq_user = 'MQServer';
$rabbitmq_password = 'IT490';

// Queue that being used
$api_data_queue_name = 'api_sendback'; // This Queue is for receiving API data

// These are the credentials for MYSQL DB
$mysql_host = 'Database-NLB-a57264455bbebb21.elb.us-east-1.amazonaws.com';
$mysql_user = 'IT490Database';
$mysql_password = 'IT490';
$mysql_database = 'Flavor';

/**
 * Send a response message back to the reply-to queue
 *
 * @param AMQPChannel $channel
 * @param AMQPMessage $msg
 * @param array $response
 */
function sendResponse(AMQPChannel $channel, AMQPMessage $msg, array $response) {
    $response_msg = new AMQPMessage(json_encode($response));
    $channel->basic_publish($response_msg, '', $msg->get('reply_to'));
}

/**
 * This sends error messages back if there is any
 * @param AMQPChannel $channel
 * @param AMQPMessage $msg
 * @param string $errorMessage
 */
function sendErrorResponse(AMQPChannel $channel, AMQPMessage $msg, string $errorMessage) {
    sendResponse($channel, $msg, ['status' => 'error', 'message' => $errorMessage]);
}

try {
    $connection = new AMQPStreamConnection($rabbitmq_host, $rabbitmq_port, $rabbitmq_user, $rabbitmq_password);
    $channel = $connection->channel();

    $channel->queue_declare($api_data_queue_name, false, false, false, false);

    $callback = function ($msg) use ($channel, $mysql_host, $mysql_user, $mysql_password, $mysql_database) {
        echo " [x] Received API Data: ", $msg->body, "\n"; // Log received message from API
    
        $dataArray = json_decode($msg->body, true);
    
        if (json_last_error() !== JSON_ERROR_NONE) {
            sendErrorResponse($channel, $msg, 'Invalid JSON data');
            return;
        }
    
        if (!is_array($dataArray) || count($dataArray) === 0) {
            sendErrorResponse($channel, $msg, 'Data is not an array or is empty');
            return;
        }
    
        $data = $dataArray[0];
    
        $expected_keys = ['idMeal', 'strMeal', 'strDrinkAlternate', 'strCategory', 'strArea', 'strInstructions', 'strMealThumb',
        'strTags', 'strYoutube', 'strIngredient1', 'strIngredient2', 'strIngredient3', 'strIngredient4',
        'strIngredient5', 'strIngredient6', 'strIngredient7', 'strIngredient8', 'strIngredient9',
        'strIngredient10', 'strIngredient11', 'strIngredient12', 'strIngredient13', 'strIngredient14',
        'strIngredient15', 'strIngredient16', 'strIngredient17', 'strIngredient18', 'strIngredient19',
        'strIngredient20', 'strMeasure1', 'strMeasure2', 'strMeasure3', 'strMeasure4', 'strMeasure5',
        'strMeasure6', 'strMeasure7', 'strMeasure8', 'strMeasure9', 'strMeasure10', 'strMeasure11',
        'strMeasure12', 'strMeasure13', 'strMeasure14', 'strMeasure15', 'strMeasure16', 'strMeasure17',
        'strMeasure18', 'strMeasure19', 'strMeasure20', 'strSource', 'strImageSource',
        'strCreativeCommonsConfirmed', 'dateModified'];
    
        foreach ($expected_keys as $key) {
            if (!array_key_exists($key, $data)) {
                echo "'$key' key not found in the JSON data\n";
                return;
            }
        }
    
        $mysqli = new mysqli($mysql_host, $mysql_user, $mysql_password, $mysql_database);
        if ($mysqli->connect_error) {
            sendErrorResponse($channel, $msg, 'Database connection failed: ' . $mysqli->connect_error);
            return;
        }
    
        $query = "INSERT IGNORE INTO meals (
            idMeal, strMeal, strDrinkAlternate, strCategory, strArea, strInstructions, strMealThumb, strTags, strYoutube,
            strIngredient1, strIngredient2, strIngredient3, strIngredient4, strIngredient5, strIngredient6, strIngredient7,
            strIngredient8, strIngredient9, strIngredient10, strIngredient11, strIngredient12, strIngredient13, strIngredient14,
            strIngredient15, strIngredient16, strIngredient17, strIngredient18, strIngredient19, strIngredient20, 
            strMeasure1, strMeasure2, strMeasure3, strMeasure4, strMeasure5, strMeasure6, strMeasure7, strMeasure8, 
            strMeasure9, strMeasure10, strMeasure11, strMeasure12, strMeasure13, strMeasure14, strMeasure15, strMeasure16, 
            strMeasure17, strMeasure18, strMeasure19, strMeasure20, strSource, strImageSource, strCreativeCommonsConfirmed, dateModified
        ) VALUES (
            ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
    
        $stmt = $mysqli->prepare($query);
    
        if (!$stmt) {
            sendErrorResponse($channel, $msg, 'Error preparing SQL statement: ' . $mysqli->error);
            return;
        }
    
        $stmt->bind_param(
            "sssssssssssssssssssssssssssssssssssssssssssssssssssss",
            $data['idMeal'], $data['strMeal'], $data['strDrinkAlternate'], $data['strCategory'], $data['strArea'],
            $data['strInstructions'], $data['strMealThumb'], $data['strTags'], $data['strYoutube'],
            $data['strIngredient1'], $data['strIngredient2'], $data['strIngredient3'], $data['strIngredient4'],
            $data['strIngredient5'], $data['strIngredient6'], $data['strIngredient7'], $data['strIngredient8'],
            $data['strIngredient9'], $data['strIngredient10'], $data['strIngredient11'], $data['strIngredient12'],
            $data['strIngredient13'], $data['strIngredient14'], $data['strIngredient15'], $data['strIngredient16'],
            $data['strIngredient17'], $data['strIngredient18'], $data['strIngredient19'], $data['strIngredient20'],
            $data['strMeasure1'], $data['strMeasure2'], $data['strMeasure3'], $data['strMeasure4'], $data['strMeasure5'],
            $data['strMeasure6'], $data['strMeasure7'], $data['strMeasure8'], $data['strMeasure9'], $data['strMeasure10'],
            $data['strMeasure11'], $data['strMeasure12'], $data['strMeasure13'], $data['strMeasure14'], $data['strMeasure15'],
            $data['strMeasure16'], $data['strMeasure17'], $data['strMeasure18'], $data['strMeasure19'], $data['strMeasure20'],
            $data['strSource'], $data['strImageSource'], $data['strCreativeCommonsConfirmed'], $data['dateModified']
        );
    
        if ($stmt->execute()) {
            echo "Inserted new meal into database\n";
        } else {
            echo "Error inserting meal: " . $stmt->error . "\n";
        }
    
        $stmt->close();
        $mysqli->close();
    };
    

    $channel->basic_consume($api_data_queue_name, '', false, false, false, false, $callback);
    echo " [*] Waiting for messages from API. To exit press CTRL+C\n";

    while ($channel->is_consuming()) {
        $channel->wait();
    }

    $channel->close();
    $connection->close();

} catch (\Exception $e) {
    echo 'Connection Error: ', $e->getMessage(), "\n";
}
?>
