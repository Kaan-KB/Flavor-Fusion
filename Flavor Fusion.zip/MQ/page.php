<?php
require_once __DIR__ . '/vendor/autoload.php';
use PhpAmqpLib\Connection\AMQPStreamConnection;
use PhpAmqpLib\Message\AMQPMessage;

// Enable error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);

// RabbitMQ connection credentials
$host = 'rabbitmq-elb-dad86311aae5d992.elb.us-east-1.amazonaws.com';
$port = 5672;
$user = 'MQServer';
$pass = 'IT490';
$queue = 'meal_data_queue';
$responseQueue = 'response_queue';
$update_queue = 'update_queue'; // Define update_queue

// Establish RabbitMQ connection and channel
$connection = new AMQPStreamConnection($host, $port, $user, $pass);
$channel = $connection->channel();

// MySQL database credentials
$dsn = 'mysql:host=Database-NLB-a57264455bbebb21.elb.us-east-1.amazonaws.com;dbname=Flavor';
$username = 'IT490Database';
$password = 'IT490';

// Initialize PDO object for database operations
$pdo = new PDO($dsn, $username, $password);
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

try {
    // Declare the queues
    $channel->queue_declare($queue, false, false, false, false);
    $channel->queue_declare($responseQueue, false, false, false, false);
    $channel->queue_declare($update_queue, false, false, false, false);

    // Callback function for handling incoming messages from meal_data_queue
    $callback = function ($msg) use ($channel, $responseQueue, $pdo) {
        $data = json_decode($msg->body, true);

        if (isset($data['action']) && $data['action'] === 'fetch_data') {
            $search = isset($data['search']) ? $data['search'] : '';
            $origin = isset($data['origin']) ? $data['origin'] : '';
            $ingredientType = isset($data['ingredientType']) ? $data['ingredientType'] : '';
            $sort = isset($data['sort']) ? $data['sort'] : 'name_asc';
            $page = isset($data['page']) ? (int)$data['page'] : 1;
            $perPage = isset($data['perPage']) ? (int)$data['perPage'] : 10;

            $result = fetchDataFromDatabase($pdo, $search, $origin, $ingredientType, $sort, $page, $perPage);

            if (isset($result['error'])) {
                $response = new AMQPMessage(
                    json_encode(['error' => $result['error']]),
                    ['correlation_id' => $msg->get('correlation_id')]
                );
            } else {
                $response = new AMQPMessage(
                    json_encode($result),
                    ['correlation_id' => $msg->get('correlation_id')]
                );
            }

            $channel->basic_publish($response, '', $msg->get('reply_to'));
        } else {
            error_log("Invalid message format or action.");
        }

        $channel->basic_ack($msg->delivery_info['delivery_tag']);
    };

    $updateCallback = function ($msg) use ($channel, $pdo) {
        $data = json_decode($msg->body, true);
        $type = $data['type'];
        $current_email = $data['current_email'];

        if ($type === 'email') {
            $new_email = $data['new_email'];
            $stmt = $pdo->prepare('UPDATE users SET email = ? WHERE email = ?');
            $stmt->execute([$new_email, $current_email]);
            echo " [x] Updated email from $current_email to $new_email\n";
        } elseif ($type === 'password') {
            $current_password = $data['current_password'];
            $new_password = password_hash($data['new_password'], PASSWORD_DEFAULT);
            $stmt = $pdo->prepare('SELECT password FROM users WHERE email = ?');
            $stmt->execute([$current_email]);
            $result = $stmt->fetch(PDO::FETCH_ASSOC);

            if ($result && password_verify($current_password, $result['password'])) {
                $stmt = $pdo->prepare('UPDATE users SET password = ? WHERE email = ?');
                $stmt->execute([$new_password, $current_email]);
                echo " [x] Updated password for $current_email\n";
            } else {
                echo " [x] Current password is incorrect for $current_email\n";
            }
        } else {
            echo " [x] Invalid message type\n";
        }

        $msg->delivery_info['channel']->basic_ack($msg->delivery_info['delivery_tag']);
    };

  
    $channel->basic_qos(0, 1, null);

    $channel->basic_consume($queue, '', false, false, false, false, $callback);

    $channel->basic_consume($update_queue, '', false, false, false, false, $updateCallback);


    echo " [*] Waiting for messages. To exit press CTRL+C\n";
    while ($channel->is_consuming()) {
        $channel->wait();
    }
} catch (Exception $e) {
    error_log("Error: " . $e->getMessage());
    http_response_code(500);
    echo json_encode(['error' => 'An error occurred. Please try again later.']);
} finally {
    $pdo = null;

    $channel->close();
    $connection->close();
}

function fetchDataFromDatabase($pdo, $search, $origin, $ingredientType, $sort, $page = 1, $perPage = 10) {
    try {
        $sql = "SELECT 
                    meals.*, 
                    COALESCE(SUM(newlike.like_count), 0) AS like_count
                FROM 
                    meals
                LEFT JOIN 
                    newlike 
                ON 
                    meals.idMeal = newlike.idmeal
                WHERE 1=1";
        
        if ($search) {
            $sql .= " AND strMeal LIKE :search";
        }
        if ($origin) {
            $sql .= " AND strArea = :origin";
        }
        if ($ingredientType) {
            $sql .= " AND strCategory LIKE :ingredientType";
        }
        
        $sql .= " GROUP BY meals.idMeal";
        
        // Sorting
        $sortColumn = 'strMeal';
        $sortOrder = 'ASC';
        
        switch ($sort) {
            case 'name_desc':
                $sortColumn = 'strMeal';
                $sortOrder = 'DESC';
                break;
            case 'likes_asc':
                $sortColumn = 'like_count';
                $sortOrder = 'ASC';
                break;
            case 'likes_desc':
                $sortColumn = 'like_count';
                $sortOrder = 'DESC';
                break;
            case 'origin_asc':
                $sortColumn = 'strArea';
                $sortOrder = 'ASC';
                break;
            case 'origin_desc':
                $sortColumn = 'strArea';
                $sortOrder = 'DESC';
                break;
        }
        
        $sql .= " ORDER BY $sortColumn $sortOrder";
        
        // Add pagination
        $offset = ($page - 1) * $perPage;
        $sql .= " LIMIT :limit OFFSET :offset";

        $stmt = $pdo->prepare($sql);

        if ($search) {
            $stmt->bindValue(':search', "%$search%");
        }
        if ($origin) {
            $stmt->bindValue(':origin', $origin);
        }
        if ($ingredientType) {
            $stmt->bindValue(':ingredientType', "%$ingredientType%");
        }
        $stmt->bindValue(':limit', (int)$perPage, PDO::PARAM_INT);
        $stmt->bindValue(':offset', (int)$offset, PDO::PARAM_INT);

        $stmt->execute();
        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);

        $countSql = "SELECT COUNT(DISTINCT meals.idMeal) FROM meals WHERE 1=1";
        
        if ($search) {
            $countSql .= " AND strMeal LIKE :search";
        }
        if ($origin) {
            $countSql .= " AND strArea = :origin";
        }
        if ($ingredientType) {
            $countSql .= " AND strCategory LIKE :ingredientType";
        }

        $countStmt = $pdo->prepare($countSql);
        
        if ($search) {
            $countStmt->bindValue(':search', "%$search%");
        }
        if ($origin) {
            $countStmt->bindValue(':origin', $origin);
        }
        if ($ingredientType) {
            $countStmt->bindValue(':ingredientType', "%$ingredientType%");
        }

        $countStmt->execute();
        $totalRecords = $countStmt->fetchColumn();
        $totalPages = ceil($totalRecords / $perPage);

        return [
            'recipes' => $result,
            'totalPages' => $totalPages
        ];
    } catch (PDOException $e) {
        error_log("Database error: " . $e->getMessage());
        return ['error' => 'Database error occurred.'];
    }
}
