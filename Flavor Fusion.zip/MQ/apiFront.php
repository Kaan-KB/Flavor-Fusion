<?php
require_once __DIR__ . '/vendor/autoload.php';

use PhpAmqpLib\Connection\AMQPStreamConnection;
use PhpAmqpLib\Message\AMQPMessage;
use PhpAmqpLib\Channel\AMQPChannel;

// RabbitMQ connection credentials
$rabbitmq_host = 'rabbitmq-elb-dad86311aae5d992.elb.us-east-1.amazonaws.com';
$rabbitmq_port = 5672;
$rabbitmq_user = 'MQServer';
$rabbitmq_password = 'IT490';

// Queue that being used
$request_queue_name = 'api_queue'; // Queue for receiving messages

/**
 * Send a response message back to the reply-to queue
 *
 * @param AMQPChannel $channel
 * @param AMQPMessage $msg
 * @param array $response
 */
function sendResponse(AMQPChannel $channel, AMQPMessage $msg, array $response) {
    $responseMsg = new AMQPMessage(json_encode($response), [
        'correlation_id' => $msg->get('correlation_id'),
        'content_type' => 'application/json',
        'delivery_mode' => AMQPMessage::DELIVERY_MODE_PERSISTENT
    ]);

    // Publish response to the reply-to queue
    $channel->basic_publish($responseMsg, '', $msg->get('reply_to'));
    $channel->basic_ack($msg->get('delivery_tag'));
}

/**
 * This sends error messages back if there is any
 *
 * @param AMQPChannel $channel
 * @param AMQPMessage $msg
 * @param string $errorMessage
 */
function sendErrorResponse(AMQPChannel $channel, AMQPMessage $msg, string $errorMessage) {
    sendResponse($channel, $msg, ['status' => 'error', 'message' => $errorMessage]);
}

try {
    // Establishes connection with RabbitMQ through AMQP 
    $connection = new AMQPStreamConnection($rabbitmq_host, $rabbitmq_port, $rabbitmq_user, $rabbitmq_password);
    $channel = $connection->channel();

    // Declare the request queue
    $channel->queue_declare($request_queue_name, false, false, false, false);

    $callback = function ($msg) use ($channel) {
        echo " [x] Received from Frontend: ", $msg->body, "\n"; // Log received message from frontend

        // This Decodes the incoming message
        $data = json_decode($msg->body, true);

        // Check if JSON decoding was successful
        if (json_last_error() !== JSON_ERROR_NONE) {
            sendErrorResponse($channel, $msg, 'Invalid JSON data');
            return;
        }

        // It Sends a success response back to the frontend
        sendResponse($channel, $msg, ['status' => 'success', 'message' => 'Request processed successfully']);
    };

    $channel->basic_consume($request_queue_name, '', false, false, false, false, $callback);
    echo " [*] Waiting for messages from Frontend. To exit press CTRL+C\n";

    while ($channel->is_consuming()) {
        $channel->wait();
    }

    $channel->close();
    $connection->close();

} catch (\Exception $e) {
    echo 'Connection Error: ', $e->getMessage(), "\n";
}
?>
