<?php
require_once __DIR__ . '/vendor/autoload.php';
use PhpAmqpLib\Connection\AMQPStreamConnection;
use PhpAmqpLib\Message\AMQPMessage;

// Enable error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);

// RabbitMQ connection credentials
$host = 'rabbitmq-elb-dad86311aae5d992.elb.us-east-1.amazonaws.com';
$port = 5672;
$user = 'MQServer';
$pass = 'IT490';
$queue = 'meal_data_queue';
$responseQueue = 'response_queue';
$update_queue = 'update_queue'; // Define update_queue
$admin_queue = 'admin_queue';   // Define admin_queue

// Establish RabbitMQ connection and channel
$connection = new AMQPStreamConnection($host, $port, $user, $pass);
$channel = $connection->channel();

// MySQL database credentials
$dsn = 'mysql:host=Database-NLB-a57264455bbebb21.elb.us-east-1.amazonaws.com;dbname=Flavor';
$username = 'IT490Database';
$password = 'IT490';

// Initialize PDO object for database operations
$pdo = new PDO($dsn, $username, $password);
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

try {
    // Where the queues are declared
    $channel->queue_declare($queue, false, false, false, false);
    $channel->queue_declare($responseQueue, false, false, false, false);
    $channel->queue_declare($update_queue, false, false, false, false);
    $channel->queue_declare($admin_queue, false, false, false, false);

    // Callback function for handling incoming messages from meal_data_queue
    $callback = function ($msg) use ($channel, $responseQueue, $pdo) {
        $data = json_decode($msg->body, true);

        if (isset($data['action']) && $data['action'] === 'fetch_data') {
            $result = fetchDataFromDatabase($pdo);

            if (isset($result['error'])) {
                $response = new AMQPMessage(
                    json_encode(['error' => $result['error']]),
                    ['correlation_id' => $msg->get('correlation_id')]
                );
            } else {
                $response = new AMQPMessage(
                    json_encode($result),
                    ['correlation_id' => $msg->get('correlation_id')]
                );
            }

            // Publish response to the reply_to queue
            $channel->basic_publish($response, '', $msg->get('reply_to'));
        } else {
            error_log("Invalid message format or action.");
        }

        // Acknowledge the message
        $channel->basic_ack($msg->delivery_info['delivery_tag']);
    };

    // Callback function for handling incoming messages from update_queue
    $updateCallback = function ($msg) use ($channel, $pdo) {
        $data = json_decode($msg->body, true);
        $type = $data['type'];
        $current_email = $data['current_email'];

        if ($type === 'email') {
            $new_email = $data['new_email'];
            $stmt = $pdo->prepare('UPDATE users SET email = ? WHERE email = ?');
            $stmt->execute([$new_email, $current_email]);
            echo " [x] Updated email from $current_email to $new_email\n";
        } elseif ($type === 'password') {
            $current_password = $data['current_password'];
            $new_password = $data['new_password'];
            $stmt = $pdo->prepare('SELECT password FROM users WHERE email = ?');
            $stmt->execute([$current_email]);
            $result = $stmt->fetch(PDO::FETCH_ASSOC);

            if ($result && password_verify($current_password, $result['password'])) {
                $stmt = $pdo->prepare('UPDATE users SET password = ? WHERE email = ?');
                $stmt->execute([$new_password, $current_email]);
                echo " [x] Updated password for $current_email\n";
            } else {
                echo " [x] Current password is incorrect for $current_email\n";
            }
        } else {
            echo " [x] Invalid message type\n";
        }

        // Acknowledge the message
        $msg->delivery_info['channel']->basic_ack($msg->delivery_info['delivery_tag']);
    };

    // Callback function for handling incoming messages from admin_queue
    $userFetchCallback = function ($msg) use ($channel, $pdo, $admin_queue) {
        // Fetch users from the database
        $stmt = $pdo->query('SELECT * FROM users');
        $users = $stmt->fetchAll(PDO::FETCH_ASSOC);

        // Send users data to admin_queue
        $data = json_encode($users);
        $response = new AMQPMessage($data);
        $channel->basic_publish($response, '', $admin_queue);
    };

    // Set prefetch count to 1 to ensure only one message is processed at a time
    $channel->basic_qos(0, 1, null);

    // Consume messages from the meal_data_queue
    $channel->basic_consume($queue, '', false, false, false, false, $callback);

    // Consume messages from the update_queue
    $channel->basic_consume($update_queue, '', false, false, false, false, $updateCallback);

    // Consume messages from the admin_queue
    $channel->basic_consume($admin_queue, '', false, false, false, false, $userFetchCallback);

    // Wait for incoming messages
    echo " [*] Waiting for messages. To exit press CTRL+C\n";
    while ($channel->is_consuming()) {
        $channel->wait();
    }
} catch (Exception $e) {
    error_log("Error in fetch_data.php: " . $e->getMessage());
    http_response_code(500);
    echo json_encode(['error' => 'An error occurred. Please try again later.']);
} finally {
    // Close PDO connection
    $pdo = null;

    // Close channel and connection
    $channel->close();
    $connection->close();
}

// Function to fetch data from the database
function fetchDataFromDatabase($pdo) {
    try {
        $stmt = $pdo->prepare("SELECT * FROM meals");
        $stmt->execute();
        $result = $stmt->fetchAll(PDO::FETCH_ASSOC); // Fetch all records

        if ($result) {
            return $result;
        } else {
            return ['error' => 'Data not found'];
        }
    } catch(PDOException $e) {
        error_log("Error fetching data: " . $e->getMessage());
        return ['error' => 'Error fetching data'];
    }
}
?>
