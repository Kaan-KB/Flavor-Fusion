<?php
require_once __DIR__ . '/vendor/autoload.php';
use PhpAmqpLib\Connection\AMQPStreamConnection;
use PhpAmqpLib\Message\AMQPMessage;

error_reporting(E_ALL);
ini_set('display_errors', 1);

$rabbitmq_host = 'rabbitmq-elb-dad86311aae5d992.elb.us-east-1.amazonaws.com';
$rabbitmq_port = 5672;
$rabbitmq_user = 'MQServer';
$rabbitmq_password = 'IT490';
$queue_name = 'recipe_details';
$responseQueue = 'response_queue'; // Response queue for sending error messages

$mysql_host = 'Database-NLB-a57264455bbebb21.elb.us-east-1.amazonaws.com';
$mysql_user = 'IT490Database';
$mysql_password = 'IT490';
$mysql_database = 'Flavor';

$mysqli = new mysqli($mysql_host, $mysql_user, $mysql_password, $mysql_database);

if ($mysqli->connect_errno) {
    echo "Failed to connect to MySQL: " . $mysqli->connect_error;
    exit();
}

$connection = new AMQPStreamConnection($rabbitmq_host, $rabbitmq_port, $rabbitmq_user, $rabbitmq_password);
$channel = $connection->channel();

$channel->queue_declare($queue_name, false, true, false, false);

function sendErrorResponse($channel, $responseQueue, $errorMessage, $correlationId, $replyTo) {
    $msg = new AMQPMessage(json_encode(['error' => $errorMessage]), [
        'correlation_id' => $correlationId
    ]);
    $channel->basic_publish($msg, '', $replyTo);
}

$callback = function ($msg) use ($mysqli, $channel, $responseQueue) {
    $requestData = json_decode($msg->body, true);
    $recipeId = $requestData['idMeal'];
    $correlationId = $msg->get('correlation_id');
    $replyTo = $msg->get('reply_to');

        // Fetch recipe data from MySQL
        $sql = "SELECT * FROM meals WHERE idMeal = ?";
        $stmt = $mysqli->prepare($sql);
        if (!$stmt) {
            sendErrorResponse($channel, $responseQueue, 'Database query error', $correlationId, $replyTo);
            return;
        }
        $stmt->bind_param("i", $recipeId);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            $recipe = $result->fetch_assoc();
            $responseMsg = new AMQPMessage(json_encode($recipe), [
                'correlation_id' => $correlationId
            ]);
            $channel->basic_publish($responseMsg, '', $replyTo);
        } else {
            sendErrorResponse($channel, $responseQueue, 'Recipe not found', $correlationId, $replyTo);
        }

        $stmt->close();
    
};

$channel->basic_consume($queue_name, '', false, true, false, false, $callback);

echo " [*] Waiting for messages. To exit press CTRL+C\n";

while ($channel->is_consuming()) {
    $channel->wait();
}

$mysqli->close();

$channel->close();
$connection->close();
?>
