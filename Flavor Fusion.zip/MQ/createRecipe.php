<?php
require_once __DIR__ . '/vendor/autoload.php';
use PhpAmqpLib\Connection\AMQPStreamConnection;
use PhpAmqpLib\Message\AMQPMessage;

// Enable error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);

// RabbitMQ connection settings
$host = 'rabbitmq-elb-dad86311aae5d992.elb.us-east-1.amazonaws.com';
$port = 5672;
$user = 'MQServer';
$pass = 'IT490';
$RecipeCreateQueue = 'recipes_queue';
$RecipeEditQueue = 'edit_recipes_queue'; // New queue for editing recipes
$RecipeDeleteQueue = 'delete_recipes_queue'; // Queue for deleting recipes
$responseQueue = 'response_queue'; // Response queue for sending error messages

$connection = new AMQPStreamConnection($host, $port, $user, $pass);
$channel = $connection->channel();

$dsn = 'mysql:host=Database-NLB-a57264455bbebb21.elb.us-east-1.amazonaws.com;dbname=Flavor';
$username = 'IT490Database';
$password = 'IT490';

$pdo = new PDO($dsn, $username, $password);
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

try {
    $channel->queue_declare($RecipeCreateQueue, false, false, false, false);
    $channel->queue_declare($RecipeEditQueue, false, false, false, false); // Declare edit queue
    $channel->queue_declare($RecipeDeleteQueue, false, false, false, false); // Declare delete queue
    $channel->queue_declare($responseQueue, false, false, false, false); // Declare response queue

    function sendErrorResponse($channel, $responseQueue, $errorMessage) {
        $msg = new AMQPMessage(json_encode(['error' => $errorMessage]));
        $channel->basic_publish($msg, '', $responseQueue);
    }

    $RecipeCreateCallback = function ($msg) use ($channel, $pdo, $responseQueue) {
        $data = json_decode($msg->body, true);

        $expected_keys = ['idMeal', 'strMeal', 'strDrinkAlternate', 'strCategory', 'strArea', 'strInstructions', 'strMealThumb',
                          'strTags', 'strYoutube', 'strIngredient1', 'strIngredient2', 'strIngredient3', 'strIngredient4',
                          'strIngredient5', 'strIngredient6', 'strIngredient7', 'strIngredient8', 'strIngredient9',
                          'strIngredient10', 'strIngredient11', 'strIngredient12', 'strIngredient13', 'strIngredient14',
                          'strIngredient15', 'strIngredient16', 'strIngredient17', 'strIngredient18', 'strIngredient19',
                          'strIngredient20', 'strMeasure1', 'strMeasure2', 'strMeasure3', 'strMeasure4', 'strMeasure5',
                          'strMeasure6', 'strMeasure7', 'strMeasure8', 'strMeasure9', 'strMeasure10', 'strMeasure11',
                          'strMeasure12', 'strMeasure13', 'strMeasure14', 'strMeasure15', 'strMeasure16', 'strMeasure17',
                          'strMeasure18', 'strMeasure19', 'strMeasure20', 'strSource', 'strImageSource',
                          'strCreativeCommonsConfirmed', 'dateModified'];

        foreach ($expected_keys as $key) {
            if (!array_key_exists($key, $data)) {
                $data[$key] = null;
            }
        }

        $sql = "INSERT INTO meals (idMeal, strMeal, strDrinkAlternate, strCategory, strArea, strInstructions, strMealThumb, strTags, strYoutube, 
                strIngredient1, strIngredient2, strIngredient3, strIngredient4, strIngredient5, strIngredient6, strIngredient7, strIngredient8, strIngredient9, strIngredient10, 
                strIngredient11, strIngredient12, strIngredient13, strIngredient14, strIngredient15, strIngredient16, strIngredient17, strIngredient18, strIngredient19, strIngredient20, 
                strMeasure1, strMeasure2, strMeasure3, strMeasure4, strMeasure5, strMeasure6, strMeasure7, strMeasure8, strMeasure9, strMeasure10, 
                strMeasure11, strMeasure12, strMeasure13, strMeasure14, strMeasure15, strMeasure16, strMeasure17, strMeasure18, strMeasure19, strMeasure20, 
                strSource, strImageSource, strCreativeCommonsConfirmed, dateModified) 
                VALUES (:idMeal, :strMeal, :strDrinkAlternate, :strCategory, :strArea, :strInstructions, :strMealThumb, :strTags, :strYoutube, 
                        :strIngredient1, :strIngredient2, :strIngredient3, :strIngredient4, :strIngredient5, :strIngredient6, :strIngredient7, :strIngredient8, :strIngredient9, :strIngredient10, 
                        :strIngredient11, :strIngredient12, :strIngredient13, :strIngredient14, :strIngredient15, :strIngredient16, :strIngredient17, :strIngredient18, :strIngredient19, :strIngredient20, 
                        :strMeasure1, :strMeasure2, :strMeasure3, :strMeasure4, :strMeasure5, :strMeasure6, :strMeasure7, :strMeasure8, :strMeasure9, :strMeasure10, 
                        :strMeasure11, :strMeasure12, :strMeasure13, :strMeasure14, :strMeasure15, :strMeasure16, :strMeasure17, :strMeasure18, :strMeasure19, :strMeasure20, 
                        :strSource, :strImageSource, :strCreativeCommonsConfirmed, :dateModified)";
        
        try {
            $stmt = $pdo->prepare($sql);
            $stmt->execute($data);
            echo " [x] Recipe added\n";
        } catch (PDOException $e) {
            if ($e->getCode() == 23000) { 
                echo " [x] Duplicate entry for idMeal: " . $data['idMeal'] . "\n";
                sendErrorResponse($channel, $responseQueue, 'Duplicate entry for idMeal: ' . $data['idMeal']);
            } else {
                throw $e; 
            }
        }

        $msg->delivery_info['channel']->basic_ack($msg->delivery_info['delivery_tag']);
    };

    $RecipeEditCallback = function ($msg) use ($channel, $pdo, $responseQueue) {
        $data = json_decode($msg->body, true);

        if (isset($data['idMeal'])) {
            $idMeal = $data['idMeal'];

            $checkSql = "SELECT COUNT(*) FROM meals WHERE idMeal = :idMeal";
            $checkStmt = $pdo->prepare($checkSql);
            $checkStmt->execute(['idMeal' => $idMeal]);
            $exists = $checkStmt->fetchColumn();

            if ($exists) {
                $expected_keys = ['idMeal', 'strMeal', 'strDrinkAlternate', 'strCategory', 'strArea', 'strInstructions', 'strMealThumb',
                                  'strTags', 'strYoutube', 'strIngredient1', 'strIngredient2', 'strIngredient3', 'strIngredient4',
                                  'strIngredient5', 'strIngredient6', 'strIngredient7', 'strIngredient8', 'strIngredient9',
                                  'strIngredient10', 'strIngredient11', 'strIngredient12', 'strIngredient13', 'strIngredient14',
                                  'strIngredient15', 'strIngredient16', 'strIngredient17', 'strIngredient18', 'strIngredient19',
                                  'strIngredient20', 'strMeasure1', 'strMeasure2', 'strMeasure3', 'strMeasure4', 'strMeasure5',
                                  'strMeasure6', 'strMeasure7', 'strMeasure8', 'strMeasure9', 'strMeasure10', 'strMeasure11',
                                  'strMeasure12', 'strMeasure13', 'strMeasure14', 'strMeasure15', 'strMeasure16', 'strMeasure17',
                                  'strMeasure18', 'strMeasure19', 'strMeasure20', 'strSource', 'strImageSource',
                                  'strCreativeCommonsConfirmed', 'dateModified'];

                foreach ($expected_keys as $key) {
                    if (!array_key_exists($key, $data)) {
                        $data[$key] = null;
                    }
                }

                $updateSql = "UPDATE meals SET strMeal = :strMeal, strDrinkAlternate = :strDrinkAlternate, strCategory = :strCategory, 
                              strArea = :strArea, strInstructions = :strInstructions, strMealThumb = :strMealThumb, strTags = :strTags, 
                              strYoutube = :strYoutube, strIngredient1 = :strIngredient1, strIngredient2 = :strIngredient2, strIngredient3 = :strIngredient3, 
                              strIngredient4 = :strIngredient4, strIngredient5 = :strIngredient5, strIngredient6 = :strIngredient6, strIngredient7 = :strIngredient7, 
                              strIngredient8 = :strIngredient8, strIngredient9 = :strIngredient9, strIngredient10 = :strIngredient10, strIngredient11 = :strIngredient11, 
                              strIngredient12 = :strIngredient12, strIngredient13 = :strIngredient13, strIngredient14 = :strIngredient14, strIngredient15 = :strIngredient15, 
                              strIngredient16 = :strIngredient16, strIngredient17 = :strIngredient17, strIngredient18 = :strIngredient18, strIngredient19 = :strIngredient19, 
                              strIngredient20 = :strIngredient20, strMeasure1 = :strMeasure1, strMeasure2 = :strMeasure2, strMeasure3 = :strMeasure3, strMeasure4 = :strMeasure4, 
                              strMeasure5 = :strMeasure5, strMeasure6 = :strMeasure6, strMeasure7 = :strMeasure7, strMeasure8 = :strMeasure8, strMeasure9 = :strMeasure9, 
                              strMeasure10 = :strMeasure10, strMeasure11 = :strMeasure11, strMeasure12 = :strMeasure12, strMeasure13 = :strMeasure13, strMeasure14 = :strMeasure14, 
                              strMeasure15 = :strMeasure15, strMeasure16 = :strMeasure16, strMeasure17 = :strMeasure17, strMeasure18 = :strMeasure18, strMeasure19 = :strMeasure19, 
                              strMeasure20 = :strMeasure20, strSource = :strSource, strImageSource = :strImageSource, strCreativeCommonsConfirmed = :strCreativeCommonsConfirmed, 
                              dateModified = :dateModified WHERE idMeal = :idMeal";

                try {
                    $stmt = $pdo->prepare($updateSql);
                    $stmt->execute($data);
                    echo " [x] Recipe with idMeal $idMeal updated\n";
                } catch (PDOException $e) {
                    error_log("Error updating recipe: " . $e->getMessage());
                    sendErrorResponse($channel, $responseQueue, 'An error occurred while updating the recipe.');
                }
            } else {
                echo " [x] Recipe with idMeal $idMeal does not exist\n";
                sendErrorResponse($channel, $responseQueue, 'Recipe with idMeal ' . $idMeal . ' does not exist');
            }
        } else {
            echo " [x] idMeal not provided\n";
            sendErrorResponse($channel, $responseQueue, 'idMeal not provided');
        }

        $msg->delivery_info['channel']->basic_ack($msg->delivery_info['delivery_tag']);
    };

    $RecipeDeleteCallback = function ($msg) use ($channel, $pdo, $responseQueue) {
        $data = json_decode($msg->body, true);

        if (isset($data['idMeal'])) {
            $idMeal = $data['idMeal'];

            $checkSql = "SELECT COUNT(*) FROM meals WHERE idMeal = :idMeal";
            $checkStmt = $pdo->prepare($checkSql);
            $checkStmt->execute(['idMeal' => $idMeal]);
            $exists = $checkStmt->fetchColumn();

            if ($exists) {
                $deleteSql = "DELETE FROM meals WHERE idMeal = :idMeal";

                try {
                    $deleteStmt = $pdo->prepare($deleteSql);
                    $deleteStmt->execute(['idMeal' => $idMeal]);
                    echo " [x] Recipe with idMeal $idMeal deleted\n";
                   
                } catch (PDOException $e) {
                    error_log("Error deleting recipe: " . $e->getMessage());
                    sendErrorResponse($channel, $responseQueue, 'An error occurred while deleting the recipe.');
                }
            } else {
                echo " [x] Recipe with idMeal $idMeal does not exist\n";
                sendErrorResponse($channel, $responseQueue, 'Recipe with idMeal ' . $idMeal . ' does not exist');
            }
        } else {
            echo " [x] idMeal not provided\n";
            sendErrorResponse($channel, $responseQueue, 'idMeal not provided');
        }

        $msg->delivery_info['channel']->basic_ack($msg->delivery_info['delivery_tag']);
    };

    $channel->basic_qos(0, 1, null);

    $channel->basic_consume($RecipeDeleteQueue, '', false, false, false, false, $RecipeDeleteCallback);
    $channel->basic_consume($RecipeCreateQueue, '', false, false, false, false, $RecipeCreateCallback);
    $channel->basic_consume($RecipeEditQueue, '', false, false, false, false, $RecipeEditCallback);
    echo " [*] Waiting for messages. To exit press CTRL+C\n";
    while ($channel->is_consuming()) {
        $channel->wait();
    }
} catch (Exception $e) {
    error_log("Error in RabbitMQ consumer: " . $e->getMessage());
    $msg = new AMQPMessage(json_encode(['error' => 'An error occurred. Please try again later.']));
    $channel->basic_publish($msg, '', $responseQueue);
}

$channel->close();
$connection->close();
?>
