<?php

require_once __DIR__ . '/vendor/autoload.php';

use PhpAmqpLib\Connection\AMQPStreamConnection;
use PhpAmqpLib\Message\AMQPMessage;

$host = 'rabbitmq-elb-dad86311aae5d992.elb.us-east-1.amazonaws.com';
$port = 5672;
$user = 'MQServer';
$pass = 'IT490';
$vhost = '/';
$userFetchQueue = 'user_fetch';
$userDeleteQueue = 'user_delete';

$mysql_host = 'Database-NLB-a57264455bbebb21.elb.us-east-1.amazonaws.com';
$mysql_user = 'IT490Database';
$mysql_password = 'IT490';
$mysql_database = 'Flavor';

$mysqli = new mysqli($mysql_host, $mysql_user, $mysql_password, $mysql_database);

if ($mysqli->connect_errno) {
    error_log("Failed to connect to MySQL: " . $mysqli->connect_error);
    exit();
} else {
    echo "Connected to MySQL successfully.\n"; // Add debugging message
}

$connection = new AMQPStreamConnection($host, $port, $user, $pass, $vhost);
$channel = $connection->channel();

$channel->queue_declare($userFetchQueue, false, true, false, false);
$channel->queue_declare($userDeleteQueue, false, true, false, false);

$callbackFetch = function ($msg) use ($mysqli, $channel) {
    $users = [];

    $stmt = $mysqli->query("SELECT id, email FROM users");
    if (!$stmt) {
        error_log("Error fetching users: " . $mysqli->error);
        return;
    }

    while ($row = $stmt->fetch_assoc()) {
        $users[] = $row;
    }

    $response = new AMQPMessage(json_encode($users), [
        'correlation_id' => $msg->get('correlation_id'),
        'reply_to' => $msg->get('reply_to')
    ]);

    $channel->basic_publish($response, '', $msg->get('reply_to'));
    error_log("User fetch response sent.");
};

$callbackDelete = function ($msg) use ($mysqli, $channel) {
    $data = json_decode($msg->body, true);
    $userId = (int)$data['userId'];
    $success = false;

    $checkStmt = $mysqli->prepare("SELECT id FROM users WHERE id = ?");
    $checkStmt->bind_param("i", $userId);
    $checkStmt->execute();
    $checkStmt->store_result();

    if ($checkStmt->num_rows === 0) {
        error_log("User with ID $userId not found.");
        $checkStmt->close();
    } else {
        $checkStmt->close();

        $stmt = $mysqli->prepare("DELETE FROM users WHERE id = ?");
        if (!$stmt) {
            error_log("Error preparing delete statement: " . $mysqli->error);
            return;
        }

        $stmt->bind_param("i", $userId);
        if ($stmt->execute()) {
            $success = true;
        } else {
            error_log("Error executing delete: " . $stmt->error);
        }
        $stmt->close();
    }

    $response = new AMQPMessage(json_encode(['success' => $success]), [
        'correlation_id' => $msg->get('correlation_id'),
        'reply_to' => $msg->get('reply_to')
    ]);

    $channel->basic_publish($response, '', $msg->get('reply_to'));
    error_log("User delete response sent for user ID: $userId.");
};

$channel->basic_consume($userFetchQueue, '', false, true, false, false, $callbackFetch);
$channel->basic_consume($userDeleteQueue, '', false, true, false, false, $callbackDelete);

echo " [*] Waiting for messages. To exit press CTRL+C\n";  

while ($channel->is_consuming()) {
    $channel->wait();
}

// Close connections
$channel->close();
$connection->close();
$mysqli->close(); 

?>
